# TroopMessenger Lead Generation Dashboard

A React dashboard to visualise and manage leads collected by the [TroopMessenger Lead Generation n8n Workflow](https://github.com/your-username/troopmessenger-lead-gen-workflow).

Reads live data directly from the Google Sheet populated by the n8n workflow. No backend required.

---

## Screenshot

> Leads table with expandable rows showing full post text, AI score, intent, pain points, and reply draft.

---

## Features

- **Leads table** — filterable by platform, urgency, score, date range, replied status, and decision-maker flag
- **Full post expand** — click any row to see the complete post title, body text, pain points, tools mentioned, outreach angle, and AI reply draft
- **One-click copy** — copy the AI-generated reply draft to clipboard instantly
- **Mark replied** — track which leads have been acted on
- **Export CSV** — download filtered leads as a CSV
- **Warmup table** — view Reddit and Quora warmup posts separately
- **Analytics** — score distribution, platform breakdown, urgency split, daily lead volume
- **Setup modal** — enter your Google Sheets API key in the UI, no config files needed

---

## Tech stack

- React 18
- Recharts (analytics charts)
- Lucide React (icons)
- Google Sheets API v4 (data source)
- Deployed on Vercel

---

## Getting started

### 1. Clone the repo

```bash
git clone https://github.com/your-username/troopmessenger-dashboard.git
cd troopmessenger-dashboard
```

### 2. Install dependencies

```bash
npm install
```

### 3. Run locally

```bash
npm start
```

Opens at `http://localhost:3000`.

### 4. Enter your Google Sheets API key

On first load, a setup modal appears. Enter:

- **Google Sheets API Key** — create one at [console.cloud.google.com](https://console.cloud.google.com) with Sheets API enabled

The key is stored in `localStorage` — it never leaves your browser.

---

## Google Sheets structure required

The dashboard expects a spreadsheet with these four tab names (same spreadsheet used by the n8n workflow):

| Tab name | Content |
|---|---|
| `Reddit_Leads` | Scored Reddit leads |
| `Quora_Leads` | Scored Quora leads |
| `Reddit_Warmup_Posts` | Reddit warmup replies |
| `Quora_Warmup_Posts` | Quora warmup answers |

The Spreadsheet ID is set in `src/sheetsService.js`:

```js
const SPREADSHEET_ID = 'your-spreadsheet-id-here';
```

Replace it with your own spreadsheet ID (found in the Google Sheets URL).

---

## Deployment (Vercel)

```bash
npm run build
```

Or connect the repo to [Vercel](https://vercel.com) for automatic deploys on push. A `vercel.json` is included.

---

## Project structure

```
src/
├── App.js                  # Routing and layout
├── index.js                # Entry point
├── sheetsService.js        # Google Sheets API + mock data
└── components/
    ├── Home.js             # Landing / summary cards
    ├── Dashboard.js        # Main dashboard shell
    ├── LeadsPage.js        # Leads table + filters
    ├── LeadsTable.js       # Table sub-component
    ├── WarmupPage.js       # Warmup posts view
    ├── WarmupTable.js      # Warmup table sub-component
    ├── Analytics.js        # Charts and stats
    └── SetupModal.js       # API key setup screen
```

---

## Related

- [TroopMessenger Lead Gen Workflow](https://github.com/your-username/troopmessenger-lead-gen-workflow) — the n8n automation that populates the sheet
- [Troop Messenger](https://www.troopmessenger.com) — the product this is built for

---

## Author

**Prathamesh Mohite**  
PGDM 2025–27 · Marketing + IT & Analytics · IMT Hyderabad  
Summer Intern · Tvisha Technologies, Hyderabad
