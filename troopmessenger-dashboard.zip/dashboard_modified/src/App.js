import React, { useState, useEffect, useCallback } from 'react';
import { fetchAllData, getStoredApiKey, setStoredApiKey } from './sheetsService';
import Home       from './components/Home';
import LeadsPage  from './components/LeadsPage';
import Analytics  from './components/Analytics';
import WarmupPage from './components/WarmupPage';
import SetupModal from './components/SetupModal';

const NAV = [
  { id:'home',      icon:'⌂',  label:'Home'      },
  { id:'leads',     icon:'◎',  label:'Leads'      },
  { id:'analytics', icon:'▦',  label:'Analytics'  },
  { id:'warmup',    icon:'⚡', label:'Warmup'     },
];

function LiveClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const days   = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return (
    <div style={{ fontSize:11, color:'#94a3b8', lineHeight:1.6 }}>
      <div style={{ color:'#475569', textTransform:'uppercase', letterSpacing:'0.08em', fontSize:10 }}>
        {days[now.getDay()]}, {months[now.getMonth()]} {now.getDate()}
      </div>
      <div style={{ fontSize:22, fontWeight:700, color:'#f1f5f9', letterSpacing:'-0.02em', fontFamily:"'JetBrains Mono', monospace" }}>
        {now.toLocaleTimeString('en-US', { hour:'2-digit', minute:'2-digit', second:'2-digit' })}
      </div>
    </div>
  );
}

export default function App() {
  const [tab,       setTab]       = useState('home');
  const [data,      setData]      = useState(null);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState(null);
  const [lastSync,  setLastSync]  = useState(null);
  const [showSetup, setShowSetup] = useState(false);
  const [syncing,   setSyncing]   = useState(false);

  const load = useCallback(async (apiKey) => {
    setSyncing(true); setError(null);
    try {
      const result = await fetchAllData(apiKey);
      setData(result);
      setLastSync(new Date());
    } catch(e) {
      setError(e.message);
    } finally {
      setSyncing(false); setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  function handleApiKeySave(key) {
    setStoredApiKey(key);
    setShowSetup(false);
    load(key);
  }

  const hasKey = !!getStoredApiKey() && !getStoredApiKey().startsWith('__n8n');

  const PAGES = { home: Home, leads: LeadsPage, analytics: Analytics, warmup: WarmupPage };
  const ActivePage = PAGES[tab];

  return (
    <div style={s.root}>
      {/* ── Sidebar ── */}
      <aside style={s.sidebar}>
        {/* Logo */}
        <div style={s.brand}>
          <img src="/logo.svg" alt="TroopMessenger" style={{ height: 18, width: 'auto', display:'block' }} />
          <div style={s.brandTag}>GTM Intelligence</div>
        </div>

        {/* Nav */}
        <nav style={s.nav}>
          {NAV.map(({ id, icon, label }) => {
            const count = id === 'leads'
              ? (data?.leads?.filter(l => l.Reply_Posted !== 'Yes').length || 0)
              : id === 'warmup'
              ? (data?.warmup?.filter(w => w.Reply_Posted !== 'Yes').length || 0)
              : 0;
            return (
              <button key={id} onClick={() => setTab(id)}
                style={{ ...s.navBtn, ...(tab === id ? s.navBtnActive : {}) }}>
                <span style={s.navIcon}>{icon}</span>
                <span style={s.navLabel}>{label}</span>
                {count > 0 && (
                  <span style={{ ...s.badge, background: tab === id ? '#1e3a5f' : '#0d1526', color: tab === id ? '#60a5fa' : '#475569' }}>
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom */}
        <div style={s.sidebarBottom}>
          <div style={s.syncBox}>
            <div style={{ display:'flex', alignItems:'center', gap:6 }}>
              <span style={{ ...s.syncDot, background: data?.live ? '#22c55e' : '#f59e0b', boxShadow: data?.live ? '0 0 6px #22c55e66' : 'none' }} />
              <span style={{ fontSize:11, color:'#475569' }}>{data?.live ? 'Live data' : 'Demo data'}</span>
            </div>
            {lastSync && (
              <div style={{ fontSize:10, color:'#334155', marginTop:2 }}>
                Synced {lastSync.toLocaleTimeString()}
              </div>
            )}
          </div>

          <button onClick={() => load()} disabled={syncing} style={s.syncBtn}>
            <span style={syncing ? { display:'inline-block', animation:'spin 0.8s linear infinite' } : {}}>↻</span>
            {syncing ? 'Syncing…' : 'Sync now'}
          </button>

          <button onClick={() => setShowSetup(true)} style={s.setupBtn}>
            {hasKey ? '⚙ Reconnect Sheets' : '⚠ Connect Google Sheets'}
          </button>
        </div>
      </aside>

      {/* ── Main ── */}
      <div style={s.main}>
        <header style={s.topbar}>
          <LiveClock />
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            {!hasKey && (
              <div style={s.alertPill} onClick={() => setShowSetup(true)}>
                ⚠ No API key — showing demo data. Click to connect.
              </div>
            )}
            {error  && <div style={s.errorPill}>⚠ {error}</div>}
            {syncing && <div style={s.loadingPill}>↻ Fetching…</div>}
          </div>
        </header>

        <div style={s.content}>
          {loading ? (
            <div style={s.loadingScreen}>
              <div style={{ fontSize:32, color:'#3b82f6', animation:'pulse 1.2s ease infinite' }}>◎</div>
              <div style={{ color:'#475569', fontSize:13, marginTop:12 }}>Loading intelligence…</div>
            </div>
          ) : (
            <ActivePage data={data} onRefresh={load} />
          )}
        </div>
      </div>

      {showSetup && (
        <SetupModal onSave={handleApiKeySave} onClose={() => setShowSetup(false)} currentKey={getStoredApiKey()} />
      )}
    </div>
  );
}

const s = {
  root:    { display:'flex', height:'100vh', overflow:'hidden', background:'#070d18', fontFamily:"'Inter',sans-serif", color:'#e2e8f0' },
  sidebar: { width:220, flexShrink:0, background:'#0d1526', borderRight:'1px solid #1e2d4a', display:'flex', flexDirection:'column', overflow:'hidden' },
  brand:   { padding:'22px 20px 18px', borderBottom:'1px solid #1e2d4a', display:'flex', flexDirection:'column', gap:6 },
  brandTag:{ fontSize:10, color:'#334155', letterSpacing:'0.08em', textTransform:'uppercase' },
  nav:     { flex:1, padding:'12px 10px', display:'flex', flexDirection:'column', gap:2, overflowY:'auto' },
  navBtn:  { display:'flex', alignItems:'center', gap:9, padding:'9px 10px', borderRadius:7, border:'none', background:'transparent', color:'#475569', fontSize:13, fontWeight:500, cursor:'pointer', textAlign:'left', width:'100%', transition:'all 0.12s', fontFamily:'inherit' },
  navBtnActive: { background:'#1e3a5f', color:'#60a5fa' },
  navIcon: { fontSize:14, width:18, textAlign:'center', flexShrink:0 },
  navLabel:{ flex:1 },
  badge:   { fontSize:10, fontWeight:700, padding:'2px 6px', borderRadius:10 },
  sidebarBottom: { padding:'12px', borderTop:'1px solid #1e2d4a', display:'flex', flexDirection:'column', gap:8 },
  syncBox: { padding:'8px 10px', background:'#0a1525', borderRadius:7 },
  syncDot: { width:7, height:7, borderRadius:'50%', flexShrink:0, display:'inline-block' },
  syncBtn: { display:'flex', alignItems:'center', justifyContent:'center', gap:6, padding:'8px', borderRadius:7, border:'1px solid #1e2d4a', background:'#0a1525', color:'#64748b', fontSize:12, cursor:'pointer', width:'100%', fontFamily:'inherit' },
  setupBtn:{ padding:'7px', borderRadius:7, border:'1px solid #1e2d4a', background:'transparent', color:'#334155', fontSize:11, cursor:'pointer', width:'100%', textAlign:'center', fontFamily:'inherit' },
  main:    { flex:1, display:'flex', flexDirection:'column', overflow:'hidden' },
  topbar:  { display:'flex', alignItems:'center', justifyContent:'space-between', padding:'16px 28px', borderBottom:'1px solid #1e2d4a', flexShrink:0 },
  content: { flex:1, overflowY:'auto', padding:'28px' },
  alertPill:  { fontSize:11, color:'#f59e0b', background:'#1c1400', border:'1px solid #2d2200', padding:'6px 12px', borderRadius:20, cursor:'pointer' },
  errorPill:  { fontSize:11, color:'#f87171', background:'#1a0000', border:'1px solid #2d0000', padding:'6px 12px', borderRadius:20 },
  loadingPill:{ fontSize:11, color:'#60a5fa', background:'#0d1a2d', padding:'6px 12px', borderRadius:20 },
  loadingScreen: { display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'60vh' },
};
