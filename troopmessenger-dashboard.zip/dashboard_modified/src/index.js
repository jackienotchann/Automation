import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// Suppress ResizeObserver loop warning (harmless Recharts issue)
const resizeObserverErr = window.onerror;
window.onerror = (msg, ...args) => {
  if (msg?.includes('ResizeObserver')) return true;
  return resizeObserverErr?.(msg, ...args);
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);