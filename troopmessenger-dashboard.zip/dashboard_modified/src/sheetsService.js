// ── Google Sheets Service ─────────────────────────────────────────────────────
// Reads 4 sheets from the TroopMessenger leads spreadsheet
// API key is stored in localStorage (set via the Setup screen in the UI)

const SPREADSHEET_ID = '1-MVY_KhE7Ac0YSmoKhv24KE1x-lGZ6HBr8mbLlHPxrw';
const BASE = 'https://sheets.googleapis.com/v4/spreadsheets';

export function getStoredApiKey() {
  return localStorage.getItem('tm_google_api_key') || '';
}
export function setStoredApiKey(key) {
  localStorage.setItem('tm_google_api_key', key);
}

async function fetchSheet(sheetName, apiKey) {
  const url = `${BASE}/${SPREADSHEET_ID}/values/${encodeURIComponent(sheetName)}?key=${apiKey}`;
  const res = await fetch(url);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error?.message || `HTTP ${res.status}`);
  }
  const data = await res.json();
  return parse(data.values || []);
}

function parse(rows) {
  if (rows.length < 2) return [];
  const headers = rows[0].map(h => String(h).trim());
  return rows.slice(1).map(row => {
    const obj = {};
    headers.forEach((h, i) => { obj[h] = row[i] !== undefined ? String(row[i]) : ''; });
    return obj;
  });
}

export async function fetchAllData(apiKey) {
  const key = apiKey || getStoredApiKey();
  if (!key || key.startsWith('__n8n_BLANK')) {
    return getMockData();
  }
  try {
    const [redditLeads, quoraLeads, redditWarmup, quoraWarmup] = await Promise.all([
      fetchSheet('Reddit_Leads',       key),
      fetchSheet('Quora_Leads',        key),
      fetchSheet('Reddit_Warmup_Posts',       key),
      fetchSheet('Quora_Warmup_Posts', key),
    ]);
    const leads = [
      ...redditLeads.map(r => ({ ...r, platform: 'Reddit' })),
      ...quoraLeads .map(r => ({ ...r, platform: 'Quora'  })),
    ];
    const warmup = [
      ...redditWarmup.map(r => ({ ...r, platform: 'Reddit' })),
      ...quoraWarmup .map(r => ({ ...r, platform: 'Quora'  })),
    ];
    return { leads, warmup, live: true };
  } catch (e) {
    throw e;
  }
}

// ── Realistic mock data ───────────────────────────────────────────────────────
function getMockData() {
  const intents   = ['looking_to_switch','evaluating_tools','frustrated_with_slack','seeking_alternative','no_intent'];
  const urgencies = ['high','medium','low'];
  const roles     = ['CTO','IT Manager','Founder','Operations','HR Manager','Developer'];
  const subs      = ['sysadmin','startups','remotework','msp','IndianStartups','SaaS','Entrepreneur','ITManagers'];
  const tools     = ['Slack','Microsoft Teams','WhatsApp','Telegram','Discord'];
  const pains     = ['too expensive','poor mobile app','no self-hosted','bad security','slow performance','limited integrations'];

  const leads = Array.from({ length: 140 }, (_, i) => {
    const score    = +(Math.random() * 0.4 + 0.6).toFixed(2);
    const platform = i % 3 === 0 ? 'Quora' : 'Reddit';
    const daysAgo  = Math.floor(Math.random() * 30);
    const d = new Date(); d.setDate(d.getDate() - daysAgo);
    return {
      POST_ID: `post_${i}`,
      Title: platform === 'Reddit'
        ? `Looking for a Slack alternative for our ${10+i*2} person remote team`
        : `What is the best team messaging tool for startups in 2025?`,
      URL: `https://reddit.com/r/${subs[i%subs.length]}/post_${i}`,
      Subreddit: platform === 'Reddit' ? subs[i % subs.length] : '',
      Author: `user_${i}`,
      AI_Score: score,
      Intent: intents[i % intents.length],
      Urgency: urgencies[i % urgencies.length],
      Poster_Role: roles[i % roles.length],
      Is_Decision_Maker: i % 3 === 0 ? 'true' : 'false',
      Pain_Points: `${tools[i%tools.length]}: ${pains[i%pains.length]}`,
      Tools_Mentioned: tools[i % tools.length],
      Outreach_Angle: 'Cost-effective Slack replacement with better security',
      Reply_Posted: i % 5 === 0 ? 'Yes' : 'No',
      Text: platform === 'Reddit'
        ? `We've been using ${tools[i%tools.length]} for a while but it's getting ${pains[i%pains.length]}. We're a ${10+i*2} person remote team and need something more reliable. Has anyone switched to something better? Self-hosted would be ideal but open to other options too.`
        : '',
      Reply_Draft: platform === 'Reddit' ? `Totally get the frustration. TroopMessenger is worth checking out — built for teams that need secure messaging without the Slack price tag. Has channels, file sharing, and even a self-hosted option.` : '',
      Answer_Draft: platform === 'Quora' ? `Great question. For teams prioritising data control, a self-hosted solution like TroopMessenger is worth evaluating — it offers on-premise deployment, end-to-end encryption, and LDAP integration without per-user SaaS pricing. Happy to share more details if helpful.` : '',
      platform,
      created_date: d.toISOString().split('T')[0],
    };
  });

  const warmup = Array.from({ length: 40 }, (_, i) => {
    const platform = i % 2 === 0 ? 'Reddit' : 'Quora';
    const daysAgo  = Math.floor(Math.random() * 14);
    const d = new Date(); d.setDate(d.getDate() - daysAgo);
    return {
      POST_ID: `warmup_${i}`,
      Title: ['Who else thinks Dhoni is still the GOAT?','Best Bollywood film of the decade?','What game has kept you hooked this year?','Most underrated sport in India?','Best comfort food ever?'][i%5],
      URL: `https://reddit.com/r/cricket/post_${i}`,
      Subreddit: subs[i % subs.length],
      Topic: ['cricket','bollywood','gaming','food','travel'][i%5],
      Warmup_Reply: 'Honestly still think no one reads the situation like him. Pure instinct.',
      Warmup_Answer: 'Kabaddi honestly deserves way more attention internationally.',
      Reply_Posted: i % 3 === 0 ? 'Yes' : 'No',
      platform,
      created_date: d.toISOString().split('T')[0],
    };
  });

  return { leads, warmup, live: false };
}
