import React, { useState, useMemo } from 'react';

const URG = { high:'#f87171', medium:'#f59e0b', low:'#475569' };

export default function LeadsPage({ data }) {
  const { leads=[] } = data||{};
  const [filters, setFilters] = useState({ platform:'all',urgency:'all',dm:false,minScore:0.6,range:'30d',replied:'all',q:'' });
  const [expanded, setExpanded] = useState(null);
  const [copied,   setCopied]   = useState(null);
  const [replied,  setReplied]  = useState({});
  const [sort,     setSort]     = useState({ col:'AI_Score', dir:'desc' });
  const setF = (k,v) => setFilters(f=>({...f,[k]:v}));

  const filtered = useMemo(() => {
    const days = filters.range==='24h'?1:filters.range==='7d'?7:30;
    const cutoff = new Date(); cutoff.setDate(cutoff.getDate()-days);
    return leads.filter(l => {
      if(filters.platform!=='all'&&l.platform!==filters.platform) return false;
      if(filters.urgency !=='all'&&l.Urgency!==filters.urgency)   return false;
      if(filters.dm&&l.Is_Decision_Maker!=='true') return false;
      if(parseFloat(l.AI_Score||0)<filters.minScore) return false;
      const isR = replied[l.POST_ID]||l.Reply_Posted==='Yes';
      if(filters.replied==='yes'&&!isR) return false;
      if(filters.replied==='no' && isR) return false;
      if(filters.q){const q=filters.q.toLowerCase();if(!l.Title?.toLowerCase().includes(q)&&!l.Subreddit?.toLowerCase().includes(q))return false;}
      return true;
    }).sort((a,b)=>{
      let av=a[sort.col],bv=b[sort.col];
      if(sort.col==='AI_Score'){av=parseFloat(av||0);bv=parseFloat(bv||0);}
      return sort.dir==='desc'?(av<bv?1:-1):(av>bv?1:-1);
    });
  }, [leads,filters,sort,replied]);

  function copy(lead){ navigator.clipboard.writeText(lead.Reply_Draft||''); setCopied(lead.POST_ID); setTimeout(()=>setCopied(null),2000); }
  function exportCSV(){
    const cols=['POST_ID','platform','Title','Subreddit','AI_Score','Intent','Urgency','Poster_Role','Is_Decision_Maker','Tools_Mentioned','URL'];
    const rows=[cols.join(','),...filtered.map(l=>cols.map(c=>`"${(l[c]||'').replace(/"/g,'""')}"`).join(','))];
    const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([rows.join('\n')],{type:'text/csv'}));a.download='leads.csv';a.click();
  }
  const toggleSort = col => setSort(s=>({col,dir:s.col===col&&s.dir==='desc'?'asc':'desc'}));

  return (
    <div style={s.page}>
      <div style={s.header}>
        <div><h2 style={s.h2}>Leads</h2><p style={s.sub}>{filtered.length} of {leads.length} posts</p></div>
        <button onClick={exportCSV} style={s.exportBtn}>↓ Export CSV</button>
      </div>

      <div style={s.filterBar}>
        <input placeholder="Search title, subreddit…" value={filters.q} onChange={e=>setF('q',e.target.value)} style={s.search}/>
        <Sel value={filters.platform} onChange={v=>setF('platform',v)} opts={[['all','All Platforms'],['Reddit','Reddit'],['Quora','Quora']]}/>
        <Sel value={filters.urgency}  onChange={v=>setF('urgency',v)}  opts={[['all','All Urgency'],['high','High'],['medium','Medium'],['low','Low']]}/>
        <Sel value={filters.range}    onChange={v=>setF('range',v)}    opts={[['24h','Last 24h'],['7d','Last 7d'],['30d','Last 30d']]}/>
        <Sel value={filters.replied}  onChange={v=>setF('replied',v)}  opts={[['all','All'],['no','Unreplied'],['yes','Replied']]}/>
        <label style={s.chk}><input type="checkbox" checked={filters.dm} onChange={e=>setF('dm',e.target.checked)} style={{accentColor:'#3b82f6'}}/>Decision Makers</label>
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <span style={{fontSize:11,color:'#475569'}}>Min score: <b style={{color:'#60a5fa'}}>{filters.minScore}</b></span>
          <input type="range" min="0" max="1" step="0.05" value={filters.minScore} onChange={e=>setF('minScore',parseFloat(e.target.value))} style={{width:70,accentColor:'#3b82f6'}}/>
        </div>
      </div>

      <div style={s.tableWrap}>
        <table style={s.table}>
          <thead>
            <tr style={s.thead}>
              {[['platform','Platform'],['Title','Title'],['AI_Score','Score'],['Urgency','Urgency'],['Poster_Role','Role'],['Is_Decision_Maker','DM'],['','Actions']].map(([col,label])=>(
                <th key={label} style={{...s.th,cursor:col?'pointer':'default'}} onClick={()=>col&&toggleSort(col)}>
                  {label}{sort.col===col&&<span style={{color:'#3b82f6',marginLeft:2}}>{sort.dir==='desc'?'↓':'↑'}</span>}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((lead,i)=>{
              const score=parseFloat(lead.AI_Score||0);
              const scoreColor=score>=0.9?'#34d399':score>=0.8?'#60a5fa':'#f59e0b';
              const isReplied=replied[lead.POST_ID]||lead.Reply_Posted==='Yes';
              const isExp=expanded===lead.POST_ID;
              return (
                <React.Fragment key={lead.POST_ID||i}>
                  <tr onClick={()=>setExpanded(isExp?null:lead.POST_ID)}
                    style={{...s.tr,background:isExp?'#111f36':(i%2===0?'#0a1525':'transparent')}}>
                    <td style={s.td}>
                      <span style={{...s.ptag,background:lead.platform==='Reddit'?'#431407':'#2e1065',color:lead.platform==='Reddit'?'#fb923c':'#a78bfa'}}>
                        {lead.platform}
                      </span>
                    </td>
                    <td style={{...s.td,maxWidth:320}}>
                      <div style={s.titleCell}>{lead.Title}</div>
                      {lead.Subreddit&&lead.Subreddit!=='Quora'&&<div style={s.subLabel}>r/{lead.Subreddit}</div>}
                    </td>
                    <td style={s.td}>
                      <span style={{...s.scoreBadge,color:scoreColor,borderColor:scoreColor+'44'}}>{score.toFixed(2)}</span>
                    </td>
                    <td style={s.td}><span style={{fontSize:11,color:URG[lead.Urgency]||'#475569',fontWeight:600}}>{lead.Urgency||'—'}</span></td>
                    <td style={{...s.td,color:'#475569',fontSize:12}}>{lead.Poster_Role||'—'}</td>
                    <td style={s.td}>{lead.Is_Decision_Maker==='true'?<span style={{color:'#34d399',fontSize:11}}>✓ Yes</span>:<span style={{color:'#1e2d4a'}}>—</span>}</td>
                    <td style={s.td} onClick={e=>e.stopPropagation()}>
                      <div style={{display:'flex',gap:5}}>
                        <button onClick={()=>copy(lead)} style={s.actionBtn} title="Copy reply">{copied===lead.POST_ID?'✓':'⎘'}</button>
                        <a href={lead.URL} target="_blank" rel="noreferrer" style={s.actionBtn} title="Open post">↗</a>
                        {!isReplied&&<button onClick={()=>setReplied(r=>({...r,[lead.POST_ID]:true}))} style={{...s.actionBtn,color:'#60a5fa',borderColor:'#1e3a5f'}}>Mark replied</button>}
                        {isReplied&&<span style={{fontSize:11,color:'#34d399',padding:'4px 8px'}}>✓ Done</span>}
                      </div>
                    </td>
                  </tr>
                  {isExp&&(
                    <tr style={{background:'#111f36'}}>
                      <td colSpan={7} style={{padding:'0 14px 16px'}}>
                        <div style={s.expandGrid}>
                          <div style={{gridColumn:'1/-1'}}>
                            <div style={s.expandLabel}>Title</div>
                            <div style={s.titleFullBox}>{lead.Title||'—'}</div>
                          </div>
                          {lead.platform==='Reddit'&&(
                            <div style={{gridColumn:'1/-1'}}>
                              <div style={s.expandLabel}>Post Text</div>
                              <div style={s.postTextBox}>{lead.Text||'No post text available.'}</div>
                            </div>
                          )}
                          {lead.platform==='Quora'&&(
                            <div style={{gridColumn:'1/-1'}}>
                              <div style={s.expandLabel}>Question Body</div>
                              <div style={{...s.postTextBox,color:'#475569',fontStyle:'italic'}}>Full question text is not stored for Quora leads — see the original post via the ↗ link above.</div>
                            </div>
                          )}
                          <EF label="Pain Points"     value={lead.Pain_Points}/>
                          <EF label="Tools Mentioned" value={lead.Tools_Mentioned}/>
                          <EF label="Outreach Angle"  value={lead.Outreach_Angle}/>
                          <div style={{gridColumn:'1/-1'}}>
                            <div style={s.expandLabel}>AI Reply Draft</div>
                            <div style={s.replyBox}>{lead.Reply_Draft||lead.Answer_Draft||'No reply draft generated.'}</div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
        {filtered.length===0&&<div style={s.empty}>No leads match your current filters.</div>}
      </div>
    </div>
  );
}

function Sel({value,onChange,opts}){return <select value={value} onChange={e=>onChange(e.target.value)} style={{padding:'7px 10px',background:'#070d18',border:'1px solid #1e2d4a',borderRadius:6,color:'#94a3b8',fontSize:12,outline:'none',cursor:'pointer',fontFamily:'inherit'}}>{opts.map(([v,l])=><option key={v} value={v}>{l}</option>)}</select>;}
function EF({label,value}){return <div><div style={{fontSize:10,color:'#334155',fontWeight:600,textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:4}}>{label}</div><div style={{fontSize:12,color:'#64748b'}}>{value||'—'}</div></div>;}

const s = {
  page:      {display:'flex',flexDirection:'column',gap:18,animation:'fadeIn 0.3s ease',maxWidth:1100},
  header:    {display:'flex',justifyContent:'space-between',alignItems:'flex-end'},
  h2:        {fontSize:22,fontWeight:800,color:'#f1f5f9',margin:0,letterSpacing:'-0.02em'},
  sub:       {fontSize:12,color:'#334155',margin:'4px 0 0'},
  exportBtn: {display:'flex',alignItems:'center',gap:6,padding:'8px 14px',background:'#1e3a5f',border:'1px solid #2d5a8e',borderRadius:7,color:'#60a5fa',fontSize:12,cursor:'pointer',fontFamily:'inherit'},
  filterBar: {display:'flex',flexWrap:'wrap',gap:8,alignItems:'center',background:'#0d1526',border:'1px solid #1e2d4a',borderRadius:10,padding:14},
  search:    {flex:1,minWidth:160,padding:'7px 12px',background:'#070d18',border:'1px solid #1e2d4a',borderRadius:6,color:'#e2e8f0',fontSize:13,outline:'none',fontFamily:'inherit'},
  chk:       {display:'flex',alignItems:'center',gap:6,fontSize:12,color:'#64748b',cursor:'pointer'},
  tableWrap: {background:'#0d1526',border:'1px solid #1e2d4a',borderRadius:10,overflow:'hidden'},
  table:     {width:'100%',borderCollapse:'collapse'},
  thead:     {background:'#070d18'},
  th:        {padding:'10px 14px',fontSize:10,color:'#334155',fontWeight:600,textTransform:'uppercase',letterSpacing:'0.06em',textAlign:'left',userSelect:'none'},
  tr:        {cursor:'pointer',transition:'background 0.1s'},
  td:        {padding:'9px 14px',fontSize:13,borderTop:'1px solid #1e2d4a',verticalAlign:'middle'},
  ptag:      {padding:'2px 7px',borderRadius:4,fontSize:10,fontWeight:700},
  titleCell: {color:'#cbd5e1',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',maxWidth:300},
  subLabel:  {fontSize:10,color:'#334155',marginTop:2},
  scoreBadge:{padding:'2px 7px',borderRadius:4,fontSize:12,fontWeight:700,fontFamily:"'JetBrains Mono',monospace",border:'1px solid',display:'inline-block'},
  actionBtn: {display:'flex',alignItems:'center',justifyContent:'center',padding:'5px 8px',background:'#1e2d4a',border:'1px solid #2d3f5e',borderRadius:5,color:'#94a3b8',cursor:'pointer',fontSize:13,textDecoration:'none',fontFamily:'inherit'},
  expandGrid:{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:14,padding:'12px 0 4px'},
  expandLabel:{fontSize:10,color:'#334155',fontWeight:600,textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:4},
  replyBox:  {background:'#070d18',border:'1px solid #1e3a5f',borderRadius:7,padding:'12px 14px',fontSize:13,color:'#94a3b8',lineHeight:1.6},
  titleFullBox:{fontSize:13,fontWeight:600,color:'#e2e8f0',padding:'8px 12px',background:'#070d18',border:'1px solid #1e2d4a',borderRadius:7,lineHeight:1.5,whiteSpace:'normal',wordBreak:'break-word'},
  postTextBox:{background:'#070d18',border:'1px solid #1e2d4a',borderRadius:7,padding:'12px 14px',fontSize:12,color:'#64748b',lineHeight:1.7,whiteSpace:'pre-wrap',wordBreak:'break-word'},
  empty:     {padding:40,textAlign:'center',color:'#1e2d4a',fontSize:14},
};
