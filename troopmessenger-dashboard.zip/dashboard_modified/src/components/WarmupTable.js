import React, { useState, useMemo } from 'react';
import { ExternalLink, Copy, CheckCircle, Flame } from 'lucide-react';

export default function WarmupTable({ data }) {
  const { warmup = [] } = data || {};

  const [filter, setFilter] = useState({ platform: 'all', replied: 'all', search: '' });
  const [copied, setCopied] = useState(null);
  const [expanded, setExpanded] = useState(null);

  const filtered = useMemo(() => {
    return warmup.filter(w => {
      if (filter.platform !== 'all' && w.platform !== filter.platform) return false;
      if (filter.replied === 'yes' && w.Reply_Posted !== 'Yes') return false;
      if (filter.replied === 'no'  && w.Reply_Posted === 'Yes') return false;
      if (filter.search) {
        const q = filter.search.toLowerCase();
        if (!w.Title?.toLowerCase().includes(q) && !(w.Topic || w.Subreddit || '').toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [warmup, filter]);

  const redditCount = warmup.filter(w => w.platform === 'Reddit').length;
  const quoraCount  = warmup.filter(w => w.platform === 'Quora').length;
  const repliedCount = warmup.filter(w => w.Reply_Posted === 'Yes').length;

  function copyText(item) {
    const text = item.Warmup_Reply || item.Warmup_Answer || '';
    navigator.clipboard.writeText(text);
    setCopied(item.POST_ID);
    setTimeout(() => setCopied(null), 2000);
  }

  const setF = (k, v) => setFilter(f => ({ ...f, [k]: v }));

  return (
    <div style={s.page}>
      {/* Header */}
      <div style={s.header}>
        <div>
          <h1 style={s.h1}>Warmup Posts</h1>
          <p style={s.sub}>Account warming activity — general interest replies to build credibility</p>
        </div>
        <div style={s.stats}>
          <StatPill label="Reddit" value={redditCount} color="#f97316" />
          <StatPill label="Quora"  value={quoraCount}  color="#a855f7" />
          <StatPill label="Replied" value={repliedCount} color="#34d399" />
        </div>
      </div>

      {/* Filters */}
      <div style={s.filterBar}>
        <input
          placeholder="Search by title or topic…"
          value={filter.search}
          onChange={e => setF('search', e.target.value)}
          style={s.searchInput}
        />
        <select value={filter.platform} onChange={e => setF('platform', e.target.value)} style={s.select}>
          <option value="all">All Platforms</option>
          <option value="Reddit">Reddit</option>
          <option value="Quora">Quora</option>
        </select>
        <select value={filter.replied} onChange={e => setF('replied', e.target.value)} style={s.select}>
          <option value="all">All Status</option>
          <option value="no">Not Posted</option>
          <option value="yes">Posted</option>
        </select>
        <span style={s.count}>{filtered.length} of {warmup.length} posts</span>
      </div>

      {/* Table */}
      <div style={s.tableWrap}>
        <table style={s.table}>
          <thead>
            <tr style={s.thead}>
              {['Platform', 'Title / Question', 'Topic / Subreddit', 'Reply Preview', 'Status', 'Actions'].map(h => (
                <th key={h} style={s.th}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((item, i) => {
              const reply = item.Warmup_Reply || item.Warmup_Answer || '';
              const isExpanded = expanded === item.POST_ID;
              const isPosted = item.Reply_Posted === 'Yes';

              return (
                <React.Fragment key={item.POST_ID || i}>
                  <tr
                    style={{ ...s.tr, background: isExpanded ? '#111f36' : (i % 2 === 0 ? '#0a1525' : 'transparent') }}
                    onClick={() => setExpanded(isExpanded ? null : item.POST_ID)}
                  >
                    <td style={s.td}>
                      <span style={{ ...s.platformTag, background: item.platform === 'Reddit' ? '#431407' : '#2e1065', color: item.platform === 'Reddit' ? '#fb923c' : '#a78bfa' }}>
                        {item.platform}
                      </span>
                    </td>
                    <td style={{ ...s.td, maxWidth: 280 }}>
                      <div style={s.titleCell}>{item.Title}</div>
                    </td>
                    <td style={s.td}>
                      <span style={s.topicTag}>
                        {item.platform === 'Reddit'
                          ? (item.Subreddit ? `r/${item.Subreddit}` : '—')
                          : (item.Topic || '—')}
                      </span>
                    </td>
                    <td style={{ ...s.td, maxWidth: 240 }}>
                      <div style={s.replyPreview}>{reply.slice(0, 90)}{reply.length > 90 ? '…' : ''}</div>
                    </td>
                    <td style={s.td}>
                      {isPosted
                        ? <span style={s.postedBadge}><CheckCircle size={11} /> Posted</span>
                        : <span style={s.pendingBadge}><Flame size={11} /> Pending</span>}
                    </td>
                    <td style={s.td} onClick={e => e.stopPropagation()}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button onClick={() => copyText(item)} style={s.actionBtn} title="Copy reply">
                          {copied === item.POST_ID
                            ? <CheckCircle size={13} color="#34d399" />
                            : <Copy size={13} />}
                        </button>
                        <a href={item.URL} target="_blank" rel="noreferrer" style={s.actionBtn} title="Open post">
                          <ExternalLink size={13} />
                        </a>
                      </div>
                    </td>
                  </tr>

                  {isExpanded && (
                    <tr style={{ background: '#111f36' }}>
                      <td colSpan={6} style={{ padding: '0 16px 16px 16px' }}>
                        <div style={s.expandBox}>
                          <div style={s.expandLabel}>Full {item.platform === 'Reddit' ? 'Reply' : 'Answer'}</div>
                          <div style={s.replyFull}>{reply || 'No reply generated.'}</div>
                          {item.URL && (
                            <a href={item.URL} target="_blank" rel="noreferrer" style={s.urlLink}>
                              <ExternalLink size={12} /> Open original post →
                            </a>
                          )}
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div style={s.empty}>No warmup posts match your filters.</div>
        )}
      </div>
    </div>
  );
}

function StatPill({ label, value, color }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 12px', background: '#0d1526', border: '1px solid #1e2d4a', borderRadius: 20, fontSize: 12 }}>
      <span style={{ color, fontWeight: 700 }}>{value}</span>
      <span style={{ color: '#64748b' }}>{label}</span>
    </div>
  );
}

const s = {
  page:     { padding: 32, display: 'flex', flexDirection: 'column', gap: 20 },
  header:   { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' },
  h1:       { fontSize: 22, fontWeight: 700, color: '#f1f5f9', margin: 0 },
  sub:      { fontSize: 13, color: '#475569', margin: '4px 0 0' },
  stats:    { display: 'flex', gap: 8 },
  filterBar: { display: 'flex', gap: 8, alignItems: 'center', background: '#0d1526', border: '1px solid #1e2d4a', borderRadius: 10, padding: 14, flexWrap: 'wrap' },
  searchInput: { flex: 1, minWidth: 200, padding: '7px 12px', background: '#070d18', border: '1px solid #1e2d4a', borderRadius: 6, color: '#e2e8f0', fontSize: 13, outline: 'none' },
  select: { padding: '7px 10px', background: '#070d18', border: '1px solid #1e2d4a', borderRadius: 6, color: '#94a3b8', fontSize: 12, outline: 'none', cursor: 'pointer' },
  count: { fontSize: 12, color: '#475569', marginLeft: 'auto' },
  tableWrap: { background: '#0d1526', border: '1px solid #1e2d4a', borderRadius: 10, overflow: 'hidden' },
  table: { width: '100%', borderCollapse: 'collapse' },
  thead: { background: '#070d18' },
  th: { padding: '10px 14px', fontSize: 11, color: '#475569', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', textAlign: 'left' },
  tr: { cursor: 'pointer', transition: 'background 0.1s' },
  td: { padding: '10px 14px', fontSize: 13, borderTop: '1px solid #1e2d4a', verticalAlign: 'middle' },
  platformTag: { padding: '2px 8px', borderRadius: 4, fontSize: 10, fontWeight: 700 },
  titleCell: { color: '#cbd5e1', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 280 },
  topicTag: { fontSize: 11, color: '#94a3b8', background: '#1e2d4a', padding: '2px 7px', borderRadius: 4 },
  replyPreview: { fontSize: 12, color: '#64748b', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  postedBadge:  { display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11, color: '#34d399', background: '#052e16', padding: '3px 8px', borderRadius: 4 },
  pendingBadge: { display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11, color: '#f59e0b', background: '#292200', padding: '3px 8px', borderRadius: 4 },
  actionBtn: { display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '5px 7px', background: '#1e2d4a', border: 'none', borderRadius: 5, color: '#94a3b8', cursor: 'pointer', textDecoration: 'none' },
  expandBox: { padding: '12px 0 4px', display: 'flex', flexDirection: 'column', gap: 10 },
  expandLabel: { fontSize: 11, color: '#475569', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' },
  replyFull: { background: '#0a1525', border: '1px solid #1e3a5f', borderRadius: 7, padding: '12px 14px', fontSize: 13, color: '#cbd5e1', lineHeight: 1.6 },
  urlLink: { display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12, color: '#60a5fa', textDecoration: 'none' },
  empty: { padding: 40, textAlign: 'center', color: '#475569', fontSize: 14 },
};
