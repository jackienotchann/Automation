import React, { useState } from 'react';

export default function SetupModal({ onSave, onClose, currentKey }) {
  const [key, setKey]           = useState(currentKey?.startsWith('__n8n') ? '' : (currentKey || ''));
  const [testing, setTesting]   = useState(false);
  const [testResult, setTestResult] = useState(null);

  async function testKey() {
    if (!key.trim()) return;
    setTesting(true); setTestResult(null);
    try {
      const res = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/1-MVY_KhE7Ac0YSmoKhv24KE1x-lGZ6HBr8mbLlHPxrw?key=${key.trim()}&fields=properties.title`
      );
      if (res.ok) setTestResult('success');
      else { const e = await res.json(); setTestResult(e?.error?.message || 'Invalid key'); }
    } catch(e) { setTestResult('Network error'); }
    finally { setTesting(false); }
  }

  return (
    <div style={s.overlay} onClick={onClose}>
      <div style={s.modal} onClick={e => e.stopPropagation()}>
        <div style={s.header}>
          <div style={s.title}>Connect Google Sheets</div>
          <button onClick={onClose} style={s.closeBtn}>✕</button>
        </div>
        <div style={s.body}>
          {[
            ['1', 'Create a Google API Key', <>Go to <a href="https://console.cloud.google.com" target="_blank" rel="noreferrer" style={s.link}>console.cloud.google.com</a> → APIs &amp; Services → Credentials → Create API Key → Enable "Google Sheets API"</>],
            ['2', 'Make your Sheet public (Viewer)', 'Open your Google Sheet → Share → Change to "Anyone with the link" → Viewer'],
          ].map(([n, title, desc]) => (
            <div key={n} style={s.step}>
              <div style={s.stepNum}>{n}</div>
              <div><div style={s.stepTitle}>{title}</div><div style={s.stepDesc}>{desc}</div></div>
            </div>
          ))}
          <div style={s.step}>
            <div style={s.stepNum}>3</div>
            <div style={{ flex:1 }}>
              <div style={s.stepTitle}>Paste your API key below</div>
              <div style={{ display:'flex', gap:8, marginTop:8 }}>
                <input value={key} onChange={e => { setKey(e.target.value); setTestResult(null); }}
                  placeholder="AIzaSy..." style={s.input} spellCheck={false} />
                <button onClick={testKey} disabled={!key.trim() || testing} style={s.testBtn}>
                  {testing ? '…' : 'Test'}
                </button>
              </div>
              {testResult === 'success' && <div style={{ fontSize:12, color:'#22c55e', marginTop:6 }}>✓ Connection successful</div>}
              {testResult && testResult !== 'success' && <div style={{ fontSize:12, color:'#f87171', marginTop:6 }}>✗ {testResult}</div>}
            </div>
          </div>
        </div>
        <div style={s.footer}>
          <button onClick={onClose} style={s.cancelBtn}>Cancel</button>
          <button onClick={() => onSave(key.trim())} disabled={!key.trim()}
            style={{ ...s.saveBtn, opacity: key.trim() ? 1 : 0.4 }}>
            Save &amp; Connect
          </button>
        </div>
      </div>
    </div>
  );
}

const s = {
  overlay:   { position:'fixed', inset:0, background:'#000000bb', display:'flex', alignItems:'center', justifyContent:'center', zIndex:1000, backdropFilter:'blur(4px)' },
  modal:     { background:'#0d1526', border:'1px solid #1e2d4a', borderRadius:14, width:480, maxWidth:'90vw' },
  header:    { display:'flex', justifyContent:'space-between', alignItems:'center', padding:'20px 24px', borderBottom:'1px solid #1e2d4a' },
  title:     { fontSize:16, fontWeight:700, color:'#f1f5f9' },
  closeBtn:  { background:'none', border:'none', color:'#475569', cursor:'pointer', fontSize:18, lineHeight:1, fontFamily:'inherit' },
  body:      { padding:'24px', display:'flex', flexDirection:'column', gap:20 },
  step:      { display:'flex', gap:14, alignItems:'flex-start' },
  stepNum:   { width:24, height:24, borderRadius:'50%', background:'#1e3a5f', border:'1px solid #2d5a8e', color:'#60a5fa', fontSize:12, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, marginTop:1 },
  stepTitle: { fontSize:13, fontWeight:600, color:'#e2e8f0', marginBottom:4 },
  stepDesc:  { fontSize:12, color:'#475569', lineHeight:1.6 },
  link:      { color:'#60a5fa', textDecoration:'none' },
  input:     { flex:1, padding:'9px 12px', background:'#070d18', border:'1px solid #1e2d4a', borderRadius:7, color:'#f1f5f9', fontSize:13, outline:'none', fontFamily:"'JetBrains Mono',monospace" },
  testBtn:   { padding:'9px 16px', background:'#1e2d4a', border:'none', borderRadius:7, color:'#94a3b8', fontSize:13, cursor:'pointer', fontFamily:'inherit', flexShrink:0 },
  footer:    { display:'flex', justifyContent:'flex-end', gap:8, padding:'16px 24px', borderTop:'1px solid #1e2d4a' },
  cancelBtn: { padding:'9px 18px', background:'transparent', border:'1px solid #1e2d4a', borderRadius:7, color:'#475569', fontSize:13, cursor:'pointer', fontFamily:'inherit' },
  saveBtn:   { padding:'9px 18px', background:'#3b82f6', border:'none', borderRadius:7, color:'#fff', fontSize:13, fontWeight:600, cursor:'pointer', fontFamily:'inherit' },
};
