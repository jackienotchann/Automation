import React, { useState, useMemo } from 'react';

export default function WarmupPage({ data }) {
  const { warmup=[] } = data||{};
  const [filter,   setFilter]   = useState({platform:'all',replied:'all',q:''});
  const [expanded, setExpanded] = useState(null);
  const [copied,   setCopied]   = useState(null);
  const setF = (k,v) => setFilter(f=>({...f,[k]:v}));

  const filtered = useMemo(()=>warmup.filter(w=>{
    if(filter.platform!=='all'&&w.platform!==filter.platform) return false;
    if(filter.replied==='yes'&&w.Reply_Posted!=='Yes') return false;
    if(filter.replied==='no' &&w.Reply_Posted==='Yes') return false;
    if(filter.q&&!(w.Title||'').toLowerCase().includes(filter.q.toLowerCase())) return false;
    return true;
  }),[warmup,filter]);

  const rCount = warmup.filter(w=>w.platform==='Reddit').length;
  const qCount = warmup.filter(w=>w.platform==='Quora').length;
  const posted  = warmup.filter(w=>w.Reply_Posted==='Yes').length;

  function copyText(item){navigator.clipboard.writeText(item.Warmup_Reply||item.Warmup_Answer||'');setCopied(item.POST_ID);setTimeout(()=>setCopied(null),2000);}

  return (
    <div style={s.page}>
      <div style={s.header}>
        <div><h2 style={s.h2}>Warmup Posts</h2><p style={s.sub}>General-interest replies to build account credibility</p></div>
        <div style={{display:'flex',gap:8}}>
          {[['Reddit',rCount,'#fb923c','#431407'],['Quora',qCount,'#a78bfa','#2e1065'],['Posted',posted,'#34d399','#052e16']].map(([l,v,c,bg])=>(
            <div key={l} style={{padding:'6px 12px',background:bg,border:`1px solid ${c}33`,borderRadius:20,display:'flex',gap:6,alignItems:'center'}}>
              <span style={{fontWeight:700,color:c,fontSize:13}}>{v}</span>
              <span style={{fontSize:11,color:'#475569'}}>{l}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={s.filterBar}>
        <input placeholder="Search by title or topic…" value={filter.q} onChange={e=>setF('q',e.target.value)} style={s.search}/>
        <Sel value={filter.platform} onChange={v=>setF('platform',v)} opts={[['all','All Platforms'],['Reddit','Reddit'],['Quora','Quora']]}/>
        <Sel value={filter.replied}  onChange={v=>setF('replied',v)}  opts={[['all','All Status'],['no','Not Posted'],['yes','Posted']]}/>
        <span style={{fontSize:11,color:'#334155',marginLeft:'auto'}}>{filtered.length} of {warmup.length}</span>
      </div>

      <div style={s.tableWrap}>
        <table style={s.table}>
          <thead>
            <tr style={s.thead}>
              {['Platform','Title / Question','Topic','Reply Preview','Status','Actions'].map(h=><th key={h} style={s.th}>{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {filtered.map((item,i)=>{
              const reply=item.Warmup_Reply||item.Warmup_Answer||'';
              const isExp=expanded===item.POST_ID;
              const isPosted=item.Reply_Posted==='Yes';
              return (
                <React.Fragment key={item.POST_ID||i}>
                  <tr onClick={()=>setExpanded(isExp?null:item.POST_ID)}
                    style={{...s.tr,background:isExp?'#111f36':(i%2===0?'#0a1525':'transparent')}}>
                    <td style={s.td}>
                      <span style={{...s.ptag,background:item.platform==='Reddit'?'#431407':'#2e1065',color:item.platform==='Reddit'?'#fb923c':'#a78bfa'}}>
                        {item.platform}
                      </span>
                    </td>
                    <td style={{...s.td,maxWidth:280}}><div style={s.titleCell}>{item.Title}</div></td>
                    <td style={s.td}>
                      <span style={s.topicTag}>{item.platform==='Reddit'?(item.Subreddit?`r/${item.Subreddit}`:'—'):(item.Topic||'—')}</span>
                    </td>
                    <td style={{...s.td,maxWidth:220}}>
                      <div style={s.preview}>{reply.slice(0,80)}{reply.length>80?'…':''}</div>
                    </td>
                    <td style={s.td}>
                      {isPosted
                        ?<span style={{fontSize:11,color:'#34d399',background:'#052e16',padding:'2px 8px',borderRadius:4}}>✓ Posted</span>
                        :<span style={{fontSize:11,color:'#f59e0b',background:'#1c1400',padding:'2px 8px',borderRadius:4}}>Pending</span>}
                    </td>
                    <td style={s.td} onClick={e=>e.stopPropagation()}>
                      <div style={{display:'flex',gap:5}}>
                        <button onClick={()=>copyText(item)} style={s.actionBtn}>{copied===item.POST_ID?'✓':'⎘'}</button>
                        <a href={item.URL} target="_blank" rel="noreferrer" style={s.actionBtn}>↗</a>
                      </div>
                    </td>
                  </tr>
                  {isExp&&(
                    <tr style={{background:'#111f36'}}>
                      <td colSpan={6} style={{padding:'0 14px 14px'}}>
                        <div style={{marginTop:12}}>
                          <div style={{fontSize:10,color:'#334155',fontWeight:600,textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:6}}>
                            Full {item.platform==='Reddit'?'Reply':'Answer'}
                          </div>
                          <div style={{background:'#070d18',border:'1px solid #1e3a5f',borderRadius:7,padding:'12px 14px',fontSize:13,color:'#94a3b8',lineHeight:1.6}}>
                            {reply||'No reply generated.'}
                          </div>
                          {item.URL&&<a href={item.URL} target="_blank" rel="noreferrer" style={{fontSize:12,color:'#60a5fa',textDecoration:'none',display:'inline-flex',alignItems:'center',gap:4,marginTop:8}}>↗ Open original post</a>}
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
        {filtered.length===0&&<div style={s.empty}>No warmup posts match your filters.</div>}
      </div>
    </div>
  );
}

function Sel({value,onChange,opts}){return <select value={value} onChange={e=>onChange(e.target.value)} style={{padding:'7px 10px',background:'#070d18',border:'1px solid #1e2d4a',borderRadius:6,color:'#94a3b8',fontSize:12,outline:'none',cursor:'pointer',fontFamily:'inherit'}}>{opts.map(([v,l])=><option key={v} value={v}>{l}</option>)}</select>;}

const s = {
  page:      {display:'flex',flexDirection:'column',gap:18,animation:'fadeIn 0.3s ease',maxWidth:1100},
  header:    {display:'flex',justifyContent:'space-between',alignItems:'flex-start'},
  h2:        {fontSize:22,fontWeight:800,color:'#f1f5f9',margin:0,letterSpacing:'-0.02em'},
  sub:       {fontSize:12,color:'#334155',margin:'4px 0 0'},
  filterBar: {display:'flex',gap:8,alignItems:'center',background:'#0d1526',border:'1px solid #1e2d4a',borderRadius:10,padding:14,flexWrap:'wrap'},
  search:    {flex:1,minWidth:200,padding:'7px 12px',background:'#070d18',border:'1px solid #1e2d4a',borderRadius:6,color:'#e2e8f0',fontSize:13,outline:'none',fontFamily:'inherit'},
  tableWrap: {background:'#0d1526',border:'1px solid #1e2d4a',borderRadius:10,overflow:'hidden'},
  table:     {width:'100%',borderCollapse:'collapse'},
  thead:     {background:'#070d18'},
  th:        {padding:'10px 14px',fontSize:10,color:'#334155',fontWeight:600,textTransform:'uppercase',letterSpacing:'0.06em',textAlign:'left'},
  tr:        {cursor:'pointer',transition:'background 0.1s'},
  td:        {padding:'9px 14px',fontSize:13,borderTop:'1px solid #1e2d4a',verticalAlign:'middle'},
  ptag:      {padding:'2px 7px',borderRadius:4,fontSize:10,fontWeight:700},
  titleCell: {color:'#cbd5e1',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',maxWidth:270},
  topicTag:  {fontSize:11,color:'#475569',background:'#1e2d4a',padding:'2px 7px',borderRadius:4},
  preview:   {fontSize:12,color:'#334155',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'},
  actionBtn: {display:'flex',alignItems:'center',justifyContent:'center',padding:'5px 8px',background:'#1e2d4a',border:'1px solid #2d3f5e',borderRadius:5,color:'#64748b',cursor:'pointer',fontSize:13,textDecoration:'none',fontFamily:'inherit'},
  empty:     {padding:40,textAlign:'center',color:'#1e2d4a',fontSize:14},
};
