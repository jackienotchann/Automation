import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';

const DONUT_COLORS = ['#3b82f6','#8b5cf6','#06b6d4','#10b981','#f59e0b','#6366f1','#0ea5e9','#a78bfa'];

function Heatmap({ leads }) {
  const cells = useMemo(() => {
    const map = {};
    leads.forEach(l => { const d = l.created_date?.split('T')[0]; if(d) map[d] = (map[d]||0)+1; });
    const result = [];
    for(let i=89; i>=0; i--) {
      const d = new Date(); d.setDate(d.getDate()-i);
      const key = d.toISOString().split('T')[0];
      result.push({ key, count: map[key]||0 });
    }
    return result;
  }, [leads]);

  const max = Math.max(...cells.map(c=>c.count), 1);

  function getColor(count) {
    if(count===0) return '#0d1526';
    const t = count/max;
    if(t>0.75) return '#3b82f6';
    if(t>0.5)  return '#1d4ed8';
    if(t>0.25) return '#1e3a5f';
    return '#172040';
  }

  const weeks = [];
  let week = [];
  cells.forEach((c,i) => { week.push(c); if(week.length===7||i===cells.length-1){weeks.push(week);week=[];} });

  return (
    <div>
      <div style={{ display:'flex', gap:2, alignItems:'flex-start' }}>
        <div style={{ display:'flex', flexDirection:'column', gap:2, marginRight:4 }}>
          {['S','M','T','W','T','F','S'].map((d,i) => (
            <div key={i} style={{ height:11, fontSize:9, color: i%2===1?'#334155':'transparent', lineHeight:'11px' }}>{d}</div>
          ))}
        </div>
        <div style={{ display:'flex', flexDirection:'column' }}>
          <div style={{ display:'flex', gap:2, marginBottom:4 }}>
            {weeks.map((_,wi) => {
              const d = new Date(weeks[wi]?.[0]?.key||'');
              const m = d.toLocaleString('default',{month:'short'});
              const isFirst = wi===0||new Date(weeks[wi-1]?.[0]?.key||'').getMonth()!==d.getMonth();
              return <div key={wi} style={{width:11,fontSize:9,color:isFirst?'#334155':'transparent',whiteSpace:'nowrap'}}>{isFirst?m:''}</div>;
            })}
          </div>
          {[0,1,2,3,4,5,6].map(day => (
            <div key={day} style={{ display:'flex', gap:2, marginBottom:2 }}>
              {weeks.map((wk,wi) => {
                const cell = wk[day];
                if(!cell) return <div key={wi} style={{width:11,height:11}}/>;
                return <div key={wi} title={`${cell.key}: ${cell.count} leads`}
                  style={{width:11,height:11,borderRadius:2,background:getColor(cell.count),cursor:'default'}}/>;
              })}
            </div>
          ))}
        </div>
      </div>
      <div style={{display:'flex',alignItems:'center',gap:4,marginTop:8}}>
        <span style={{fontSize:10,color:'#334155'}}>Less</span>
        {[0,0.25,0.5,0.75,1].map((v,i)=>(
          <div key={i} style={{width:11,height:11,borderRadius:2,background:v===0?'#0d1526':v<0.4?'#172040':v<0.65?'#1e3a5f':v<0.85?'#1d4ed8':'#3b82f6'}}/>
        ))}
        <span style={{fontSize:10,color:'#334155'}}>More</span>
      </div>
    </div>
  );
}

export default function Home({ data }) {
  const { leads=[], warmup=[] } = data||{};

  const stats = useMemo(() => {
    const last7 = new Date(); last7.setDate(last7.getDate()-7);
    const recentLeads = leads.filter(l => new Date(l.created_date) >= last7);
    const scores = leads.map(l=>parseFloat(l.AI_Score||0)).filter(s=>s>0);
    const avgScore = scores.length ? Math.round((scores.reduce((a,b)=>a+b,0)/scores.length)*100) : 0;
    const replied  = leads.filter(l=>l.Reply_Posted==='Yes').length;

    const subMap={};
    leads.filter(l=>l.platform==='Reddit').forEach(l=>{ if(l.Subreddit) subMap[l.Subreddit]=(subMap[l.Subreddit]||0)+1; });
    const subData = Object.entries(subMap).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([name,value])=>({name:`r/${name}`,value}));
    const subTotal = subData.reduce((a,b)=>a+b.value,0);

    const kwMap={};
    leads.forEach(l=>{ const kw=(l.Tools_Mentioned||'').trim(); if(kw) kwMap[kw]=(kwMap[kw]||0)+1; });
    const kwData = Object.entries(kwMap).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([name,value])=>({name,value}));
    const kwTotal = kwData.reduce((a,b)=>a+b.value,0);

    let streak=0;
    for(let i=0;;i++){
      const d=new Date(); d.setDate(d.getDate()-i);
      const key=d.toISOString().split('T')[0];
      if(leads.some(l=>l.created_date?.startsWith(key))) streak++;
      else break;
    }

    return { recentLeads, avgScore, replied, subData, subTotal, kwData, kwTotal,
      topSub:subData[0]?.name||'—', topSubCount:subData[0]?.value||0,
      topKw:kwData[0]?.name||'—', topKwCount:kwData[0]?.value||0,
      streak, total:leads.length, warmupTotal:warmup.length };
  }, [leads, warmup]);

  const TT = { background:'#0d1526', border:'1px solid #1e2d4a', color:'#cbd5e1', fontSize:11, borderRadius:7 };

  return (
    <div style={s.page}>
      <div style={s.greeting}>
        <div style={s.greetLabel}>TROOPMESSENGER GTM INTELLIGENCE</div>
        <h1 style={s.greetTitle}>Good {getGreeting()}, Maccha.</h1>
      </div>

      {/* Stats */}
      <section>
        <SectionHead icon="▦" label="BY THE NUMBERS · LAST 7 DAYS" />
        <div style={s.statRow}>
          {[
            { icon:'◎', label:'Posts landed',   value:stats.recentLeads.length, color:'#60a5fa' },
            { icon:'◉', label:'Avg relevance',  value:stats.avgScore+'%',       color:'#34d399' },
            { icon:'↩', label:'Replies sent',   value:stats.replied,            color:'#a78bfa' },
            { icon:'⚡', label:'Active streak', value:stats.streak+'d',         color:'#f59e0b' },
          ].map(({ icon, label, value, color }) => (
            <div key={label} style={s.statCard}>
              <div style={{ fontSize:18, marginBottom:8, color }}>{icon}</div>
              <div style={{ ...s.statValue, color }}>{value}</div>
              <div style={s.statLabel}>{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Top sources */}
      <section>
        <SectionHead icon="◉" label="TOP SOURCES" />
        <div style={s.sourcesRow}>
          {/* Subreddits */}
          <div style={s.sourceCard}>
            <div style={s.sourceCardTitle}><span style={{color:'#f97316',marginRight:6}}>◉</span> Subreddits</div>
            <div style={{display:'flex',alignItems:'center',gap:20}}>
              <div style={{position:'relative',width:120,height:120,flexShrink:0}}>
                <ResponsiveContainer width={120} height={120}>
                  <PieChart>
                    <Pie data={stats.subData} cx={55} cy={55} innerRadius={36} outerRadius={54}
                      dataKey="value" startAngle={90} endAngle={-270} paddingAngle={2} stroke="none">
                      {stats.subData.map((_,i)=><Cell key={i} fill={DONUT_COLORS[i%DONUT_COLORS.length]}/>)}
                    </Pie>
                    <Tooltip contentStyle={TT}/>
                  </PieChart>
                </ResponsiveContainer>
                <div style={s.donutCenter}>
                  <div style={s.donutNum}>{stats.subTotal}</div>
                  <div style={s.donutSub}>posts</div>
                </div>
              </div>
              <div style={s.legendList}>
                {stats.subData.slice(0,6).map(({name,value},i)=>(
                  <div key={name} style={s.legendRow}>
                    <span style={{...s.legendDot,background:DONUT_COLORS[i%DONUT_COLORS.length]}}/>
                    <span style={s.legendName}>{name}</span>
                    <span style={s.legendPct}>{stats.subTotal?Math.round(value/stats.subTotal*100):0}%</span>
                  </div>
                ))}
                {stats.subData.length>6&&<div style={{fontSize:10,color:'#334155',marginTop:2}}>+{stats.subData.length-6} more</div>}
              </div>
            </div>
          </div>

          {/* Keywords */}
          <div style={s.sourceCard}>
            <div style={s.sourceCardTitle}><span style={{color:'#60a5fa',marginRight:6}}>#</span> Keywords &amp; Tools</div>
            <div style={{display:'flex',alignItems:'center',gap:20}}>
              <div style={{position:'relative',width:120,height:120,flexShrink:0}}>
                <ResponsiveContainer width={120} height={120}>
                  <PieChart>
                    <Pie data={stats.kwData} cx={55} cy={55} innerRadius={36} outerRadius={54}
                      dataKey="value" startAngle={90} endAngle={-270} paddingAngle={2} stroke="none">
                      {stats.kwData.map((_,i)=><Cell key={i} fill={DONUT_COLORS[i%DONUT_COLORS.length]}/>)}
                    </Pie>
                    <Tooltip contentStyle={TT}/>
                  </PieChart>
                </ResponsiveContainer>
                <div style={s.donutCenter}>
                  <div style={s.donutNum}>{stats.kwTotal}</div>
                  <div style={s.donutSub}>mentions</div>
                </div>
              </div>
              <div style={s.legendList}>
                {stats.kwData.slice(0,6).map(({name,value},i)=>(
                  <div key={name} style={s.legendRow}>
                    <span style={{...s.legendDot,background:DONUT_COLORS[i%DONUT_COLORS.length]}}/>
                    <span style={s.legendName}>{name}</span>
                    <span style={s.legendPct}>{value}</span>
                  </div>
                ))}
                {stats.kwData.length>6&&<div style={{fontSize:10,color:'#334155',marginTop:2}}>+{stats.kwData.length-6} more</div>}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Activity heatmap */}
      <section>
        <SectionHead icon="↗" label="YOUR ACTIVITY" />
        <div style={s.activityCard}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:20}}>
            <div style={s.sourceCardTitle}><span style={{marginRight:6}}>↗</span> Reply activity</div>
            <span style={{fontSize:11,color:'#334155'}}>Last 90 days</span>
          </div>
          <div style={{display:'flex',gap:40,alignItems:'flex-start',flexWrap:'wrap'}}>
            <Heatmap leads={leads}/>
            <div style={{display:'flex',flexDirection:'column',gap:14}}>
              <div style={s.actStat}>
                <div style={{...s.actStatIcon,background:'#1e3a5f',color:'#60a5fa'}}>◎</div>
                <div>
                  <div style={s.actStatLabel}>Top Community</div>
                  <div style={{fontSize:13,color:'#e2e8f0',fontWeight:600}}>{stats.topSub}</div>
                  <div style={{fontSize:11,color:'#334155'}}>({stats.topSubCount} leads)</div>
                </div>
              </div>
              <div style={s.actStat}>
                <div style={{...s.actStatIcon,background:'#2e1065',color:'#a78bfa'}}>#</div>
                <div>
                  <div style={s.actStatLabel}>Top Keyword</div>
                  <div style={{fontSize:13,color:'#e2e8f0',fontWeight:600}}>{stats.topKw}</div>
                  <div style={{fontSize:11,color:'#334155'}}>({stats.topKwCount} mentions)</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function SectionHead({ icon, label }) {
  return (
    <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:14}}>
      <span style={{fontSize:13,color:'#3b82f6'}}>{icon}</span>
      <span style={{fontSize:11,color:'#334155',letterSpacing:'0.1em',textTransform:'uppercase',fontWeight:600}}>{label}</span>
    </div>
  );
}

function getGreeting() {
  const h = new Date().getHours();
  return h<12?'morning':h<17?'afternoon':'evening';
}

const s = {
  page:      { display:'flex',flexDirection:'column',gap:28,animation:'fadeIn 0.3s ease',maxWidth:1000 },
  greeting:  { marginBottom:4 },
  greetLabel:{ fontSize:10,color:'#334155',letterSpacing:'0.1em',textTransform:'uppercase',marginBottom:8 },
  greetTitle:{ fontSize:28,fontWeight:800,color:'#f1f5f9',letterSpacing:'-0.02em',margin:0 },
  statRow:   { display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12 },
  statCard:  { background:'#0d1526',border:'1px solid #1e2d4a',borderRadius:10,padding:'16px 18px' },
  statValue: { fontSize:28,fontWeight:800,letterSpacing:'-0.02em',lineHeight:1,marginBottom:4,fontFamily:"'JetBrains Mono',monospace" },
  statLabel: { fontSize:11,color:'#334155' },
  sourcesRow:{ display:'grid',gridTemplateColumns:'1fr 1fr',gap:14 },
  sourceCard:{ background:'#0d1526',border:'1px solid #1e2d4a',borderRadius:10,padding:'18px 20px' },
  sourceCardTitle:{ fontSize:13,fontWeight:600,color:'#64748b',marginBottom:16,display:'flex',alignItems:'center' },
  donutCenter:{ position:'absolute',top:'50%',left:'50%',transform:'translate(-50%,-50%)',textAlign:'center',pointerEvents:'none' },
  donutNum:  { fontSize:18,fontWeight:800,color:'#f1f5f9',lineHeight:1,fontFamily:"'JetBrains Mono',monospace" },
  donutSub:  { fontSize:9,color:'#334155',letterSpacing:'0.08em' },
  legendList:{ display:'flex',flexDirection:'column',gap:5,flex:1 },
  legendRow: { display:'flex',alignItems:'center',gap:6 },
  legendDot: { width:8,height:8,borderRadius:'50%',flexShrink:0 },
  legendName:{ fontSize:11,color:'#64748b',flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',maxWidth:100 },
  legendPct: { fontSize:11,color:'#334155',flexShrink:0 },
  activityCard:{ background:'#0d1526',border:'1px solid #1e2d4a',borderRadius:10,padding:'18px 20px' },
  actStat:   { display:'flex',alignItems:'flex-start',gap:10 },
  actStatIcon:{ width:30,height:30,borderRadius:7,border:'1px solid #1e2d4a',display:'flex',alignItems:'center',justifyContent:'center',fontSize:13,flexShrink:0 },
  actStatLabel:{ fontSize:10,color:'#334155',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:2 },
};
