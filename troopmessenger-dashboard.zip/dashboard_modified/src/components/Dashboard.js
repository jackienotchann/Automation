import React, { useMemo } from 'react';
import { Target, TrendingUp, Users, Zap, Clock, CheckCircle2, AlertTriangle, Activity } from 'lucide-react';

export default function Dashboard({ data }) {
  const stats = useMemo(() => {
    if (!data) return null;
    const { leads, warmup } = data;

    const today = new Date().toISOString().split('T')[0];
    const leadsToday = leads.filter(l => l.created_date === today).length;

    const highIntent = leads.filter(l => parseFloat(l.AI_Score) >= 0.8).length;
    const decisionMakers = leads.filter(l => l.Is_Decision_Maker === 'true').length;
    const replied = leads.filter(l => l.Reply_Posted === 'Yes').length;

    const avgScore = leads.length
      ? (leads.reduce((s, l) => s + parseFloat(l.AI_Score || 0), 0) / leads.length).toFixed(2)
      : 0;

    const redditLeads = leads.filter(l => l.platform === 'Reddit').length;
    const quoraLeads  = leads.filter(l => l.platform === 'Quora').length;

    const urgencyHigh = leads.filter(l => l.Urgency === 'high').length;

    // Recent 10 leads
    const recent = [...leads]
      .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
      .slice(0, 8);

    // Score distribution
    const buckets = { '0.6–0.7': 0, '0.7–0.8': 0, '0.8–0.9': 0, '0.9–1.0': 0 };
    leads.forEach(l => {
      const s = parseFloat(l.AI_Score || 0);
      if (s >= 0.9) buckets['0.9–1.0']++;
      else if (s >= 0.8) buckets['0.8–0.9']++;
      else if (s >= 0.7) buckets['0.7–0.8']++;
      else if (s >= 0.6) buckets['0.6–0.7']++;
    });

    return { leadsToday, highIntent, decisionMakers, replied, avgScore, redditLeads, quoraLeads, urgencyHigh, recent, buckets, total: leads.length, warmupTotal: warmup.length };
  }, [data]);

  if (!stats) return null;

  const statCards = [
    { label: 'Total Leads',     value: stats.total,          icon: Target,       color: '#3b82f6', bg: '#1e3a5f' },
    { label: 'High Intent (≥0.8)', value: stats.highIntent,  icon: Zap,          color: '#f59e0b', bg: '#292200' },
    { label: 'Decision Makers', value: stats.decisionMakers, icon: Users,        color: '#8b5cf6', bg: '#2e1065' },
    { label: 'Avg AI Score',    value: stats.avgScore,        icon: TrendingUp,   color: '#34d399', bg: '#052e16' },
    { label: 'Replies Sent',    value: stats.replied,         icon: CheckCircle2, color: '#22d3ee', bg: '#083344' },
    { label: 'High Urgency',    value: stats.urgencyHigh,     icon: AlertTriangle,color: '#f87171', bg: '#2d0a0a' },
  ];

  return (
    <div style={s.page}>
      {/* Header */}
      <div style={s.header}>
        <div>
          <h1 style={s.h1}>Operations Dashboard</h1>
          <p style={s.subtitle}>Real-time GTM intelligence for TroopMessenger</p>
        </div>
        <div style={s.headerRight}>
          <div style={s.platformPill}>
            <span style={{ ...s.dot, background: '#f97316' }} />Reddit: {stats.redditLeads}
          </div>
          <div style={s.platformPill}>
            <span style={{ ...s.dot, background: '#a855f7' }} />Quora: {stats.quoraLeads}
          </div>
        </div>
      </div>

      {/* Stat Cards */}
      <div style={s.grid6}>
        {statCards.map(({ label, value, icon: Icon, color, bg }) => (
          <div key={label} style={s.card}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div style={{ ...s.cardValue, color }}>{value}</div>
                <div style={s.cardLabel}>{label}</div>
              </div>
              <div style={{ ...s.cardIcon, background: bg }}>
                <Icon size={16} color={color} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Score Distribution + Platform Breakdown */}
      <div style={s.row2}>
        {/* Score buckets */}
        <div style={s.card}>
          <div style={s.cardTitle}>Score Distribution</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 16 }}>
            {Object.entries(stats.buckets).reverse().map(([label, count]) => {
              const pct = stats.total ? Math.round((count / stats.total) * 100) : 0;
              const color = label.startsWith('0.9') ? '#34d399'
                : label.startsWith('0.8') ? '#60a5fa'
                : label.startsWith('0.7') ? '#f59e0b'
                : '#94a3b8';
              return (
                <div key={label}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontSize: 12, color: '#94a3b8', fontFamily: 'JetBrains Mono, monospace' }}>{label}</span>
                    <span style={{ fontSize: 12, color, fontWeight: 600 }}>{count} ({pct}%)</span>
                  </div>
                  <div style={{ height: 6, background: '#1e2d4a', borderRadius: 3 }}>
                    <div style={{ height: '100%', width: `${pct}%`, background: color, borderRadius: 3, transition: 'width 0.6s ease' }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Platform split */}
        <div style={s.card}>
          <div style={s.cardTitle}>Platform Breakdown</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 16 }}>
            {[
              { label: 'Reddit', count: stats.redditLeads, color: '#f97316', pct: stats.total ? Math.round((stats.redditLeads / stats.total) * 100) : 0 },
              { label: 'Quora',  count: stats.quoraLeads,  color: '#a855f7', pct: stats.total ? Math.round((stats.quoraLeads  / stats.total) * 100) : 0 },
            ].map(({ label, count, color, pct }) => (
              <div key={label}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <span style={{ fontSize: 13, color: '#cbd5e1', fontWeight: 500 }}>{label}</span>
                  <span style={{ fontSize: 13, color, fontWeight: 600 }}>{count} leads ({pct}%)</span>
                </div>
                <div style={{ height: 8, background: '#1e2d4a', borderRadius: 4 }}>
                  <div style={{ height: '100%', width: `${pct}%`, background: color, borderRadius: 4, transition: 'width 0.6s ease' }} />
                </div>
              </div>
            ))}
            <div style={{ marginTop: 8, paddingTop: 12, borderTop: '1px solid #1e2d4a' }}>
              <div style={{ fontSize: 12, color: '#64748b', marginBottom: 6 }}>Warmup Posts</div>
              <div style={{ display: 'flex', gap: 16 }}>
                <span style={{ fontSize: 22, fontWeight: 700, color: '#60a5fa' }}>{stats.warmupTotal}</span>
                <span style={{ fontSize: 12, color: '#475569', alignSelf: 'flex-end', marginBottom: 2 }}>total warmup posts saved</span>
              </div>
            </div>
          </div>
        </div>

        {/* Reply status */}
        <div style={s.card}>
          <div style={s.cardTitle}>Reply Status</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 16 }}>
            {[
              { label: 'Replied', value: stats.replied, color: '#34d399', bg: '#052e16' },
              { label: 'Pending', value: stats.total - stats.replied, color: '#f59e0b', bg: '#292200' },
            ].map(({ label, value, color, bg }) => (
              <div key={label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', background: bg, borderRadius: 8 }}>
                <span style={{ fontSize: 13, color: '#cbd5e1' }}>{label}</span>
                <span style={{ fontSize: 20, fontWeight: 700, color }}>{value}</span>
              </div>
            ))}
            <div style={{ marginTop: 4, fontSize: 12, color: '#475569', textAlign: 'center' }}>
              {stats.total ? Math.round((stats.replied / stats.total) * 100) : 0}% reply rate
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div style={s.card}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
          <Activity size={16} color="#60a5fa" />
          <span style={s.cardTitle}>Recent Leads</span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {stats.recent.map((lead, i) => (
            <div key={lead.POST_ID || i} style={{ ...s.activityRow, background: i % 2 === 0 ? '#0d1526' : 'transparent' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1, minWidth: 0 }}>
                <span style={{ ...s.platformTag, background: lead.platform === 'Reddit' ? '#431407' : '#2e1065', color: lead.platform === 'Reddit' ? '#fb923c' : '#a78bfa' }}>
                  {lead.platform}
                </span>
                <span style={s.activityTitle}>{lead.Title}</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0 }}>
                <span style={{ ...s.scoreBadge, color: parseFloat(lead.AI_Score) >= 0.9 ? '#34d399' : parseFloat(lead.AI_Score) >= 0.8 ? '#60a5fa' : '#f59e0b' }}>
                  {parseFloat(lead.AI_Score || 0).toFixed(2)}
                </span>
                <span style={{ fontSize: 11, color: '#475569' }}>{lead.created_date}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const s = {
  page:     { padding: '32px', display: 'flex', flexDirection: 'column', gap: 24 },
  header:   { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' },
  h1:       { fontSize: 22, fontWeight: 700, color: '#f1f5f9', margin: 0 },
  subtitle: { fontSize: 13, color: '#475569', marginTop: 4, margin: 0 },
  headerRight: { display: 'flex', gap: 8 },
  platformPill: { display: 'flex', alignItems: 'center', gap: 6, padding: '6px 12px', background: '#0d1526', borderRadius: 20, border: '1px solid #1e2d4a', fontSize: 12, color: '#94a3b8' },
  dot: { width: 7, height: 7, borderRadius: '50%', display: 'inline-block' },
  grid6: { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 },
  row2:  { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 },
  card: { background: '#0d1526', border: '1px solid #1e2d4a', borderRadius: 10, padding: '20px' },
  cardTitle: { fontSize: 12, fontWeight: 600, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em' },
  cardValue: { fontSize: 32, fontWeight: 700, lineHeight: 1, marginBottom: 4 },
  cardLabel: { fontSize: 12, color: '#64748b' },
  cardIcon:  { width: 36, height: 36, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center' },
  activityRow: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 12px', borderRadius: 6, gap: 12 },
  activityTitle: { fontSize: 13, color: '#cbd5e1', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 500 },
  platformTag: { padding: '2px 7px', borderRadius: 4, fontSize: 10, fontWeight: 600, flexShrink: 0 },
  scoreBadge: { fontSize: 12, fontWeight: 700, fontFamily: 'JetBrains Mono, monospace' },
};
