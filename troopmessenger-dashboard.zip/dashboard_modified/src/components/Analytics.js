import React, { useMemo } from 'react';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';

const C  = ['#3b82f6','#8b5cf6','#06b6d4','#10b981','#f59e0b','#6366f1','#0ea5e9','#a78bfa'];
const TT = { background:'#0d1526', border:'1px solid #1e2d4a', color:'#cbd5e1', fontSize:11, borderRadius:7 };

export default function Analytics({ data }) {
  const { leads=[] } = data||{};

  const charts = useMemo(() => {
    const dateMap={};
    for(let i=13;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const k=d.toISOString().split('T')[0];dateMap[k]={date:k.slice(5),reddit:0,quora:0};}
    leads.forEach(l=>{const d=l.created_date?.split('T')[0];if(dateMap[d]){if(l.platform==='Reddit')dateMap[d].reddit++;else dateMap[d].quora++;}});
    const overTime=Object.values(dateMap);

    const subMap={};
    leads.filter(l=>l.platform==='Reddit').forEach(l=>{if(l.Subreddit)subMap[l.Subreddit]=(subMap[l.Subreddit]||0)+1;});
    const topSubs=Object.entries(subMap).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([name,count])=>({name:`r/${name}`,count}));

    const painMap={};
    leads.forEach(l=>(l.Pain_Points||'').split(',').forEach(p=>{const c=p.trim().toLowerCase();if(c&&c.length>2)painMap[c]=(painMap[c]||0)+1;}));
    const painPoints=Object.entries(painMap).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([name,count])=>({name,count}));

    const toolMap={};
    leads.forEach(l=>(l.Tools_Mentioned||'').split(',').forEach(t=>{const c=t.trim();if(c)toolMap[c]=(toolMap[c]||0)+1;}));
    const tools=Object.entries(toolMap).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([name,value])=>({name,value}));

    const intMap={};
    leads.forEach(l=>{const k=(l.Intent||'unknown').replace(/_/g,' ');intMap[k]=(intMap[k]||0)+1;});
    const intent=Object.entries(intMap).sort((a,b)=>b[1]-a[1]).map(([name,value])=>({name,value}));

    const hist=[{range:'0.6–0.7',count:0},{range:'0.7–0.8',count:0},{range:'0.8–0.9',count:0},{range:'0.9–1.0',count:0}];
    leads.forEach(l=>{const sc=parseFloat(l.AI_Score||0);if(sc>=0.9)hist[3].count++;else if(sc>=0.8)hist[2].count++;else if(sc>=0.7)hist[1].count++;else if(sc>=0.6)hist[0].count++;});

    const urgByPlatform=[{platform:'Reddit',high:0,medium:0,low:0},{platform:'Quora',high:0,medium:0,low:0}];
    leads.forEach(l=>{const row=urgByPlatform.find(r=>r.platform===l.platform);if(row&&l.Urgency)row[l.Urgency]=(row[l.Urgency]||0)+1;});

    return {overTime,topSubs,painPoints,tools,intent,hist,urgByPlatform};
  },[leads]);

  return (
    <div style={s.page}>
      <div><h2 style={s.h2}>Analytics</h2><p style={s.sub}>Patterns across {leads.length} leads</p></div>

      <div style={s.card}>
        <div style={s.ct}>Leads discovered — last 14 days</div>
        <ResponsiveContainer width="100%" height={180}>
          <AreaChart data={charts.overTime} margin={{top:10,right:10,left:-25,bottom:0}}>
            <defs>
              <linearGradient id="rg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#f97316" stopOpacity={0.3}/><stop offset="95%" stopColor="#f97316" stopOpacity={0}/></linearGradient>
              <linearGradient id="qg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#a855f7" stopOpacity={0.3}/><stop offset="95%" stopColor="#a855f7" stopOpacity={0}/></linearGradient>
            </defs>
            <XAxis dataKey="date" tick={{fill:'#334155',fontSize:10}} axisLine={false} tickLine={false}/>
            <YAxis tick={{fill:'#334155',fontSize:10}} axisLine={false} tickLine={false}/>
            <Tooltip contentStyle={TT}/>
            <Area type="monotone" dataKey="reddit" stroke="#f97316" fill="url(#rg)" strokeWidth={2} name="Reddit"/>
            <Area type="monotone" dataKey="quora"  stroke="#a855f7" fill="url(#qg)" strokeWidth={2} name="Quora"/>
            <Legend wrapperStyle={{fontSize:11,color:'#475569'}}/>
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div style={s.row2}>
        <div style={s.card}>
          <div style={s.ct}>Top subreddits</div>
          <ResponsiveContainer width="100%" height={210}>
            <BarChart data={charts.topSubs} layout="vertical" margin={{top:0,right:10,left:10,bottom:0}}>
              <XAxis type="number" tick={{fill:'#334155',fontSize:10}} axisLine={false} tickLine={false}/>
              <YAxis type="category" dataKey="name" tick={{fill:'#64748b',fontSize:11}} axisLine={false} tickLine={false} width={95}/>
              <Tooltip contentStyle={TT} cursor={{fill:'#1e2d4a'}}/>
              <Bar dataKey="count" fill="#3b82f6" radius={[0,4,4,0]} name="Leads"/>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div style={s.card}>
          <div style={s.ct}>Urgency by platform</div>
          <ResponsiveContainer width="100%" height={210}>
            <BarChart data={charts.urgByPlatform} margin={{top:10,right:10,left:-25,bottom:0}}>
              <XAxis dataKey="platform" tick={{fill:'#64748b',fontSize:12}} axisLine={false} tickLine={false}/>
              <YAxis tick={{fill:'#334155',fontSize:10}} axisLine={false} tickLine={false}/>
              <Tooltip contentStyle={TT}/>
              <Bar dataKey="high"   fill="#f87171" radius={[3,3,0,0]} name="High"   stackId="a"/>
              <Bar dataKey="medium" fill="#f59e0b" name="Medium" stackId="a"/>
              <Bar dataKey="low"    fill="#334155" radius={[0,0,3,3]} name="Low" stackId="a"/>
              <Legend wrapperStyle={{fontSize:11,color:'#475569'}}/>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div style={s.row2}>
        <div style={s.card}>
          <div style={s.ct}>Top pain points</div>
          <ResponsiveContainer width="100%" height={210}>
            <BarChart data={charts.painPoints} layout="vertical" margin={{top:0,right:10,left:10,bottom:0}}>
              <XAxis type="number" tick={{fill:'#334155',fontSize:10}} axisLine={false} tickLine={false}/>
              <YAxis type="category" dataKey="name" tick={{fill:'#64748b',fontSize:10}} axisLine={false} tickLine={false} width={115}/>
              <Tooltip contentStyle={TT} cursor={{fill:'#1e2d4a'}}/>
              <Bar dataKey="count" fill="#8b5cf6" radius={[0,4,4,0]} name="Mentions"/>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div style={s.card}>
          <div style={s.ct}>Competitor tools mentioned</div>
          <ResponsiveContainer width="100%" height={210}>
            <PieChart>
              <Pie data={charts.tools} cx="50%" cy="50%" innerRadius={55} outerRadius={80} dataKey="value" nameKey="name" paddingAngle={3} stroke="none">
                {charts.tools.map((_,i)=><Cell key={i} fill={C[i%C.length]}/>)}
              </Pie>
              <Tooltip contentStyle={TT}/>
              <Legend wrapperStyle={{fontSize:11,color:'#475569'}}/>
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div style={s.card}>
        <div style={s.ct}>Score distribution</div>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={charts.hist} margin={{top:10,right:10,left:-25,bottom:0}}>
            <XAxis dataKey="range" tick={{fill:'#64748b',fontSize:11}} axisLine={false} tickLine={false}/>
            <YAxis tick={{fill:'#334155',fontSize:10}} axisLine={false} tickLine={false}/>
            <Tooltip contentStyle={TT} cursor={{fill:'#1e2d4a'}}/>
            <Bar dataKey="count" radius={[4,4,0,0]} name="Posts">
              {charts.hist.map((_,i)=><Cell key={i} fill={['#334155','#f59e0b','#60a5fa','#34d399'][i]}/>)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div style={s.card}>
        <div style={s.ct}>Intent distribution</div>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={charts.intent} margin={{top:10,right:10,left:-25,bottom:20}}>
            <XAxis dataKey="name" tick={{fill:'#64748b',fontSize:10}} axisLine={false} tickLine={false} angle={-10} textAnchor="end"/>
            <YAxis tick={{fill:'#334155',fontSize:10}} axisLine={false} tickLine={false}/>
            <Tooltip contentStyle={TT} cursor={{fill:'#1e2d4a'}}/>
            <Bar dataKey="value" radius={[4,4,0,0]} name="Leads">
              {charts.intent.map((_,i)=><Cell key={i} fill={C[i%C.length]}/>)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

const s = {
  page:{display:'flex',flexDirection:'column',gap:20,animation:'fadeIn 0.3s ease',maxWidth:1000},
  h2:  {fontSize:22,fontWeight:800,color:'#f1f5f9',margin:0,letterSpacing:'-0.02em'},
  sub: {fontSize:12,color:'#334155',margin:'4px 0 0'},
  card:{background:'#0d1526',border:'1px solid #1e2d4a',borderRadius:10,padding:'18px 20px'},
  ct:  {fontSize:11,color:'#334155',textTransform:'uppercase',letterSpacing:'0.08em',fontWeight:600,marginBottom:14},
  row2:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16},
};
