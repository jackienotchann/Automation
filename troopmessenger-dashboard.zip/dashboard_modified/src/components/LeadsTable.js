import React, { useState, useMemo } from 'react';
import { Copy, ExternalLink, CheckCircle, Filter, Download, ChevronDown, ChevronUp } from 'lucide-react';

const URGENCY_COLOR = { high: '#f87171', medium: '#f59e0b', low: '#94a3b8' };
const URGENCY_BG    = { high: '#2d0a0a', medium: '#292200', low: '#1e2d4a' };

export default function LeadsTable({ data }) {
  const { leads = [] } = data || {};

  const [filters, setFilters] = useState({
    platform: 'all',
    urgency:  'all',
    decisionMaker: false,
    minScore: 0.6,
    dateRange: '30d',
    replied: 'all',
    search: '',
  });
  const [expandedRow, setExpandedRow] = useState(null);
  const [sortBy, setSortBy] = useState({ col: 'AI_Score', dir: 'desc' });
  const [copied, setCopied] = useState(null);
  const [localReplied, setLocalReplied] = useState({});

  const filtered = useMemo(() => {
    const cutoff = new Date();
    const days = filters.dateRange === '24h' ? 1 : filters.dateRange === '7d' ? 7 : 30;
    cutoff.setDate(cutoff.getDate() - days);

    return leads.filter(l => {
      if (filters.platform !== 'all' && l.platform !== filters.platform) return false;
      if (filters.urgency  !== 'all' && l.Urgency !== filters.urgency)   return false;
      if (filters.decisionMaker && l.Is_Decision_Maker !== 'true') return false;
      if (parseFloat(l.AI_Score || 0) < filters.minScore) return false;
      if (filters.replied !== 'all') {
        const isReplied = localReplied[l.POST_ID] || l.Reply_Posted === 'Yes';
        if (filters.replied === 'yes' && !isReplied) return false;
        if (filters.replied === 'no'  &&  isReplied) return false;
      }
      if (filters.search) {
        const q = filters.search.toLowerCase();
        if (!l.Title?.toLowerCase().includes(q) && !l.Subreddit?.toLowerCase().includes(q) && !l.Poster_Role?.toLowerCase().includes(q)) return false;
      }
      return true;
    }).sort((a, b) => {
      let av = a[sortBy.col], bv = b[sortBy.col];
      if (sortBy.col === 'AI_Score') { av = parseFloat(av || 0); bv = parseFloat(bv || 0); }
      if (sortBy.dir === 'asc') return av > bv ? 1 : -1;
      return av < bv ? 1 : -1;
    });
  }, [leads, filters, sortBy, localReplied]);

  function copyReply(lead) {
    navigator.clipboard.writeText(lead.Reply_Draft || '');
    setCopied(lead.POST_ID);
    setTimeout(() => setCopied(null), 2000);
  }

  function markReplied(lead) {
    setLocalReplied(prev => ({ ...prev, [lead.POST_ID]: true }));
  }

  function exportCSV() {
    const cols = ['POST_ID', 'platform', 'Title', 'Subreddit', 'AI_Score', 'Intent', 'Urgency', 'Poster_Role', 'Is_Decision_Maker', 'Pain_Points', 'Tools_Mentioned', 'URL'];
    const rows = [cols.join(','), ...filtered.map(l => cols.map(c => `"${(l[c] || '').replace(/"/g, '""')}"`).join(','))];
    const blob = new Blob([rows.join('\n')], { type: 'text/csv' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'troopmessenger_leads.csv'; a.click();
  }

  function toggleSort(col) {
    setSortBy(prev => ({ col, dir: prev.col === col && prev.dir === 'desc' ? 'asc' : 'desc' }));
  }

  const SortIcon = ({ col }) => sortBy.col === col
    ? (sortBy.dir === 'desc' ? <ChevronDown size={12} /> : <ChevronUp size={12} />)
    : null;

  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  return (
    <div style={s.page}>
      {/* Header */}
      <div style={s.header}>
        <div>
          <h1 style={s.h1}>Leads</h1>
          <p style={s.sub}>{filtered.length} of {leads.length} leads</p>
        </div>
        <button onClick={exportCSV} style={s.exportBtn}>
          <Download size={14} /> Export CSV
        </button>
      </div>

      {/* Filters */}
      <div style={s.filterBar}>
        <input
          placeholder="Search title, subreddit, role…"
          value={filters.search}
          onChange={e => setFilter('search', e.target.value)}
          style={s.searchInput}
        />
        <FilterSelect label="Platform" value={filters.platform} onChange={v => setFilter('platform', v)}
          options={[['all','All Platforms'],['Reddit','Reddit'],['Quora','Quora']]} />
        <FilterSelect label="Urgency" value={filters.urgency} onChange={v => setFilter('urgency', v)}
          options={[['all','All Urgency'],['high','High'],['medium','Medium'],['low','Low']]} />
        <FilterSelect label="Period" value={filters.dateRange} onChange={v => setFilter('dateRange', v)}
          options={[['24h','Last 24h'],['7d','Last 7d'],['30d','Last 30d']]} />
        <FilterSelect label="Replied" value={filters.replied} onChange={v => setFilter('replied', v)}
          options={[['all','All'],['no','Not Replied'],['yes','Replied']]} />
        <label style={s.checkLabel}>
          <input type="checkbox" checked={filters.decisionMaker} onChange={e => setFilter('decisionMaker', e.target.checked)} style={{ accentColor: '#3b82f6' }} />
          Decision Makers
        </label>
        <div style={s.scoreFilter}>
          <span style={s.scoreLabel}>Min score: <b style={{ color: '#60a5fa' }}>{filters.minScore}</b></span>
          <input type="range" min="0" max="1" step="0.05" value={filters.minScore}
            onChange={e => setFilter('minScore', parseFloat(e.target.value))}
            style={{ width: 80, accentColor: '#3b82f6' }} />
        </div>
      </div>

      {/* Table */}
      <div style={s.tableWrap}>
        <table style={s.table}>
          <thead>
            <tr style={s.thead}>
              {[
                ['platform', 'Platform'],
                ['Title',    'Title'],
                ['AI_Score', 'Score'],
                ['Intent',   'Intent'],
                ['Urgency',  'Urgency'],
                ['Poster_Role', 'Role'],
                ['Is_Decision_Maker', 'DM'],
                ['', 'Actions'],
              ].map(([col, label]) => (
                <th key={label} style={{ ...s.th, cursor: col ? 'pointer' : 'default' }}
                  onClick={() => col && toggleSort(col)}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                    {label} {col && <SortIcon col={col} />}
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((lead, i) => {
              const isReplied = localReplied[lead.POST_ID] || lead.Reply_Posted === 'Yes';
              const score = parseFloat(lead.AI_Score || 0);
              const scoreColor = score >= 0.9 ? '#34d399' : score >= 0.8 ? '#60a5fa' : '#f59e0b';
              const expanded = expandedRow === lead.POST_ID;

              return (
                <React.Fragment key={lead.POST_ID || i}>
                  <tr style={{ ...s.tr, background: expanded ? '#111f36' : (i % 2 === 0 ? '#0a1525' : 'transparent') }}
                    onClick={() => setExpandedRow(expanded ? null : lead.POST_ID)}>
                    <td style={s.td}>
                      <span style={{ ...s.platformTag, background: lead.platform === 'Reddit' ? '#431407' : '#2e1065', color: lead.platform === 'Reddit' ? '#fb923c' : '#a78bfa' }}>
                        {lead.platform}
                      </span>
                    </td>
                    <td style={{ ...s.td, maxWidth: 320 }}>
                      <div style={s.titleCell}>{lead.Title}</div>
                      {lead.Subreddit && lead.Subreddit !== 'Quora' && (
                        <div style={s.subredditLabel}>r/{lead.Subreddit}</div>
                      )}
                    </td>
                    <td style={s.td}>
                      <span style={{ ...s.scoreBadge, color: scoreColor, border: `1px solid ${scoreColor}33` }}>
                        {score.toFixed(2)}
                      </span>
                    </td>
                    <td style={s.td}>
                      <span style={s.intentTag}>{(lead.Intent || '').replace(/_/g, ' ')}</span>
                    </td>
                    <td style={s.td}>
                      <span style={{ ...s.urgencyTag, color: URGENCY_COLOR[lead.Urgency] || '#94a3b8', background: URGENCY_BG[lead.Urgency] || '#1e2d4a' }}>
                        {lead.Urgency || '—'}
                      </span>
                    </td>
                    <td style={{ ...s.td, color: '#94a3b8', fontSize: 12 }}>{lead.Poster_Role || '—'}</td>
                    <td style={s.td}>
                      {lead.Is_Decision_Maker === 'true'
                        ? <span style={s.dmYes}>✓ Yes</span>
                        : <span style={s.dmNo}>No</span>}
                    </td>
                    <td style={s.td} onClick={e => e.stopPropagation()}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button onClick={() => copyReply(lead)} style={s.actionBtn} title="Copy reply">
                          {copied === lead.POST_ID ? <CheckCircle size={13} color="#34d399" /> : <Copy size={13} />}
                        </button>
                        <a href={lead.URL} target="_blank" rel="noreferrer" style={s.actionBtn} title="Open post">
                          <ExternalLink size={13} />
                        </a>
                        {!isReplied && (
                          <button onClick={() => markReplied(lead)} style={{ ...s.actionBtn, ...s.replyBtn }} title="Mark replied">
                            Replied
                          </button>
                        )}
                        {isReplied && <span style={s.repliedBadge}>✓ Done</span>}
                      </div>
                    </td>
                  </tr>

                  {/* Expanded row */}
                  {expanded && (
                    <tr style={{ background: '#111f36' }}>
                      <td colSpan={8} style={{ padding: '0 16px 16px 16px' }}>
                        <div style={s.expandGrid}>
                          {/* Full title — spans all 3 columns */}
                          <div style={{ gridColumn: '1 / -1' }}>
                            <div style={s.expandLabel}>Title</div>
                            <div style={s.titleFullBox}>{lead.Title || '—'}</div>
                          </div>
                          {/* Full post text — spans all 3 columns */}
                          <div style={{ gridColumn: '1 / -1' }}>
                            <div style={s.expandLabel}>Post Text</div>
                            <div style={s.postTextBox}>{lead.Text || lead.text || 'No post text available.'}</div>
                          </div>
                          <ExpandField label="Pain Points"    value={lead.Pain_Points} />
                          <ExpandField label="Tools Mentioned" value={lead.Tools_Mentioned} />
                          <ExpandField label="Outreach Angle" value={lead.Outreach_Angle} />
                          <div style={{ gridColumn: '1 / -1' }}>
                            <div style={s.expandLabel}>AI Reply Draft</div>
                            <div style={s.replyDraftBox}>{lead.Reply_Draft || 'No reply draft generated.'}</div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div style={s.empty}>No leads match your current filters.</div>
        )}
      </div>
    </div>
  );
}

function FilterSelect({ value, onChange, options }) {
  return (
    <select value={value} onChange={e => onChange(e.target.value)} style={s.select}>
      {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
    </select>
  );
}

function ExpandField({ label, value }) {
  return (
    <div>
      <div style={s.expandLabel}>{label}</div>
      <div style={s.expandValue}>{value || '—'}</div>
    </div>
  );
}

const s = {
  page:     { padding: 32, display: 'flex', flexDirection: 'column', gap: 20 },
  header:   { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' },
  h1:       { fontSize: 22, fontWeight: 700, color: '#f1f5f9', margin: 0 },
  sub:      { fontSize: 13, color: '#475569', margin: '4px 0 0' },
  exportBtn: { display: 'flex', alignItems: 'center', gap: 6, padding: '8px 16px', background: '#1e3a5f', border: '1px solid #2d5a8e', borderRadius: 7, color: '#60a5fa', fontSize: 13, cursor: 'pointer' },
  filterBar: { display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center', background: '#0d1526', border: '1px solid #1e2d4a', borderRadius: 10, padding: 14 },
  searchInput: { flex: 1, minWidth: 180, padding: '7px 12px', background: '#070d18', border: '1px solid #1e2d4a', borderRadius: 6, color: '#e2e8f0', fontSize: 13, outline: 'none' },
  select: { padding: '7px 10px', background: '#070d18', border: '1px solid #1e2d4a', borderRadius: 6, color: '#94a3b8', fontSize: 12, cursor: 'pointer', outline: 'none' },
  checkLabel: { display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: '#94a3b8', cursor: 'pointer' },
  scoreFilter: { display: 'flex', alignItems: 'center', gap: 8 },
  scoreLabel: { fontSize: 12, color: '#64748b', whiteSpace: 'nowrap' },
  tableWrap: { background: '#0d1526', border: '1px solid #1e2d4a', borderRadius: 10, overflow: 'hidden' },
  table: { width: '100%', borderCollapse: 'collapse' },
  thead: { background: '#070d18' },
  th: { padding: '10px 14px', fontSize: 11, color: '#475569', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', textAlign: 'left', userSelect: 'none' },
  tr: { cursor: 'pointer', transition: 'background 0.1s' },
  td: { padding: '10px 14px', fontSize: 13, borderTop: '1px solid #1e2d4a', verticalAlign: 'middle' },
  titleCell: { color: '#cbd5e1', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 300 },
  subredditLabel: { fontSize: 11, color: '#475569', marginTop: 2 },
  platformTag: { padding: '2px 8px', borderRadius: 4, fontSize: 10, fontWeight: 700 },
  scoreBadge: { padding: '2px 8px', borderRadius: 4, fontSize: 12, fontWeight: 700, fontFamily: 'JetBrains Mono, monospace', display: 'inline-block' },
  intentTag:  { fontSize: 11, color: '#94a3b8', background: '#1e2d4a', padding: '2px 7px', borderRadius: 4, whiteSpace: 'nowrap' },
  urgencyTag: { fontSize: 11, fontWeight: 600, padding: '2px 7px', borderRadius: 4, whiteSpace: 'nowrap' },
  dmYes: { fontSize: 11, color: '#34d399', background: '#052e16', padding: '2px 7px', borderRadius: 4 },
  dmNo:  { fontSize: 11, color: '#475569' },
  actionBtn: { display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '5px 7px', background: '#1e2d4a', border: 'none', borderRadius: 5, color: '#94a3b8', cursor: 'pointer', textDecoration: 'none' },
  replyBtn:    { background: '#1e3a5f', color: '#60a5fa', fontSize: 11, padding: '4px 8px' },
  repliedBadge: { fontSize: 11, color: '#34d399', padding: '4px 8px' },
  expandGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14, padding: '12px 0 4px' },
  expandLabel: { fontSize: 11, color: '#475569', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 },
  expandValue: { fontSize: 13, color: '#94a3b8' },
  titleFullBox:  { fontSize: 14, fontWeight: 600, color: '#e2e8f0', lineHeight: 1.5, padding: '8px 12px', background: '#0a1525', border: '1px solid #1e2d4a', borderRadius: 7 },
  postTextBox:   { background: '#0a1525', border: '1px solid #1e2d4a', borderRadius: 7, padding: '12px 14px', fontSize: 13, color: '#94a3b8', lineHeight: 1.7, whiteSpace: 'pre-wrap', maxHeight: 180, overflowY: 'auto' },
  replyDraftBox: { background: '#0a1525', border: '1px solid #1e3a5f', borderRadius: 7, padding: '12px 14px', fontSize: 13, color: '#cbd5e1', lineHeight: 1.6 },
  empty: { padding: 40, textAlign: 'center', color: '#475569', fontSize: 14 },
};
